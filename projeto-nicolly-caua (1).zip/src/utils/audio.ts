// Sound manager supporting custom user audio tracks + synthesized gentle lo-fi chords fallback
import { getAudioBlobFromDB, saveAudioBlobToDB, removeAudioBlobFromDB } from './audioStorage';

class SoundManager {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private timer: number | null = null;
  private masterGain: GainNode | null = null;
  private audioElement: HTMLAudioElement | null = null;
  private audioSourceType: 'pixote' | 'custom' | 'lofi' = 'pixote';
  private currentTrackName = 'Pixote - Mande Um Sinal (15 Anos - Ao Vivo)';
  private customAudioUrl: string | null = null;
  private volume = 0.6;
  private stateChangeListeners: ((playing: boolean) => void)[] = [];
  private trackChangeListeners: ((name: string, type: 'pixote' | 'custom' | 'lofi') => void)[] = [];
  private externalPlayer: { play: () => void; pause: () => void; setVolume: (vol: number) => void } | null = null;

  constructor() {
    this.initAudioElement();
    this.loadSavedCustomAudio();
  }

  private initAudioElement() {
    if (typeof window === 'undefined') return;
    this.audioElement = new Audio();
    this.audioElement.loop = true;
    this.audioElement.volume = this.volume;

    this.audioElement.onplay = () => {
      this.isPlaying = true;
      this.notifyState();
    };

    this.audioElement.onpause = () => {
      this.isPlaying = false;
      this.notifyState();
    };

    this.audioElement.onerror = (e) => {
      console.warn('Audio playback error, falling back to lofi:', e);
      if (this.isPlaying) {
        this.audioSourceType = 'lofi';
        this.startLofiMusic();
      }
    };
  }

  private async loadSavedCustomAudio() {
    try {
      // Check localStorage for audio URL first
      const savedUrl = localStorage.getItem('nicolly_caua_music_url');
      const savedName = localStorage.getItem('nicolly_caua_music_name');

      if (savedUrl) {
        this.setCustomAudioUrl(savedUrl, savedName || 'Música do Casal');
        return;
      }

      // Check IndexedDB for uploaded file blob
      const stored = await getAudioBlobFromDB();
      if (stored && stored.blob) {
        const objectUrl = URL.createObjectURL(stored.blob);
        this.customAudioUrl = objectUrl;
        this.audioSourceType = 'custom';
        this.currentTrackName = stored.name;
        if (this.audioElement) {
          this.audioElement.src = objectUrl;
        }
        this.notifyTrack();
      }
    } catch (err) {
      console.warn('Could not load custom audio:', err);
    }
  }

  public subscribeState(listener: (playing: boolean) => void) {
    this.stateChangeListeners.push(listener);
    listener(this.isPlaying);
    return () => {
      this.stateChangeListeners = this.stateChangeListeners.filter((l) => l !== listener);
    };
  }

  public subscribeTrack(listener: (name: string, type: 'pixote' | 'custom' | 'lofi') => void) {
    this.trackChangeListeners.push(listener);
    listener(this.currentTrackName, this.audioSourceType);
    return () => {
      this.trackChangeListeners = this.trackChangeListeners.filter((l) => l !== listener);
    };
  }

  public registerExternalPlayer(player: { play: () => void; pause: () => void; setVolume: (v: number) => void }) {
    this.externalPlayer = player;
    this.externalPlayer.setVolume(this.volume);
    if (this.isPlaying && this.audioSourceType === 'pixote') {
      this.externalPlayer.play();
    }
  }

  public notifyExternalPlaybackState(playing: boolean) {
    if (this.audioSourceType === 'pixote') {
      this.isPlaying = playing;
      this.notifyState();
    }
  }

  private notifyState() {
    this.stateChangeListeners.forEach((l) => l(this.isPlaying));
  }

  private notifyTrack() {
    this.trackChangeListeners.forEach((l) => l(this.currentTrackName, this.audioSourceType));
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume * 0.4, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private playChord(freqs: number[], duration = 2.8) {
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;

    freqs.forEach((freq) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(650, now);
      filter.frequency.exponentialRampToValueAtTime(350, now + duration);

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.08, now + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + duration);
    });
  }

  private startLofiMusic() {
    this.initCtx();
    this.isPlaying = true;
    this.notifyState();
    const chords = [
      [277.18, 349.23, 415.3, 523.25], // Dbmaj7
      [261.63, 311.13, 392.0, 466.16], // Cm7
      [233.08, 277.18, 349.23, 415.3], // Bbm7
      [220.0, 277.18, 329.63, 415.3],  // Aaug/warm transition
    ];
    let chordIndex = 0;

    const cycle = () => {
      if (!this.isPlaying || this.audioSourceType !== 'lofi') return;
      this.playChord(chords[chordIndex % chords.length], 3.4);
      chordIndex++;
      this.timer = window.setTimeout(cycle, 3600);
    };

    cycle();
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.externalPlayer) {
      this.externalPlayer.setVolume(this.volume);
    }
    if (this.audioElement) {
      this.audioElement.volume = this.volume;
    }
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume * 0.4, this.ctx.currentTime);
    }
  }

  public getVolume() {
    return this.volume;
  }

  public async setCustomAudioFile(file: File, customName?: string) {
    const name = customName || file.name.replace(/\.[^/.]+$/, '');
    await saveAudioBlobToDB(file, name);

    if (this.customAudioUrl) {
      URL.revokeObjectURL(this.customAudioUrl);
    }

    const objectUrl = URL.createObjectURL(file);
    this.customAudioUrl = objectUrl;
    this.audioSourceType = 'custom';
    this.currentTrackName = name;

    localStorage.removeItem('nicolly_caua_music_url');
    localStorage.setItem('nicolly_caua_music_name', name);

    if (this.audioElement) {
      this.audioElement.src = objectUrl;
      if (this.isPlaying) {
        this.stopLofiMusic();
        this.audioElement.play().catch(console.warn);
      }
    }

    this.notifyTrack();
  }

  public setCustomAudioUrl(url: string, name: string) {
    if (this.customAudioUrl && this.customAudioUrl.startsWith('blob:')) {
      URL.revokeObjectURL(this.customAudioUrl);
    }
    this.customAudioUrl = url;
    this.audioSourceType = 'custom';
    this.currentTrackName = name;

    localStorage.setItem('nicolly_caua_music_url', url);
    localStorage.setItem('nicolly_caua_music_name', name);

    if (this.audioElement) {
      this.audioElement.src = url;
      if (this.isPlaying) {
        this.stopLofiMusic();
        this.audioElement.play().catch(console.warn);
      }
    }

    this.notifyTrack();
  }

  public async resetToPixote() {
    await removeAudioBlobFromDB();
    localStorage.removeItem('nicolly_caua_music_url');
    localStorage.removeItem('nicolly_caua_music_name');

    if (this.audioElement) {
      this.audioElement.pause();
      this.audioElement.src = '';
    }

    this.stopLofiMusic();
    this.audioSourceType = 'pixote';
    this.currentTrackName = 'Pixote - Mande Um Sinal (15 Anos - Ao Vivo)';
    this.customAudioUrl = null;

    if (this.isPlaying && this.externalPlayer) {
      this.externalPlayer.play();
    }

    this.notifyTrack();
  }

  public async resetToLofi() {
    await removeAudioBlobFromDB();
    localStorage.removeItem('nicolly_caua_music_url');
    localStorage.removeItem('nicolly_caua_music_name');

    if (this.externalPlayer) {
      this.externalPlayer.pause();
    }

    if (this.audioElement) {
      this.audioElement.pause();
      this.audioElement.src = '';
    }

    this.audioSourceType = 'lofi';
    this.currentTrackName = 'Trilha Lo-Fi Romântica';
    this.customAudioUrl = null;

    if (this.isPlaying) {
      this.startLofiMusic();
    }

    this.notifyTrack();
  }

  public toggleMusic(): boolean {
    if (this.isPlaying) {
      this.stopMusic();
      return false;
    } else {
      this.playMusic();
      return true;
    }
  }

  public playMusic() {
    this.isPlaying = true;
    if (this.audioSourceType === 'pixote') {
      this.stopLofiMusic();
      if (this.audioElement) this.audioElement.pause();
      if (this.externalPlayer) {
        this.externalPlayer.play();
      } else {
        // Fallback to lofi until external player is ready
        this.startLofiMusic();
      }
    } else if (this.audioSourceType === 'custom' && this.audioElement && this.audioElement.src) {
      this.stopLofiMusic();
      if (this.externalPlayer) this.externalPlayer.pause();
      this.audioElement.play().catch((err) => {
        console.warn('Cannot autoplay audio element, falling back to lofi:', err);
        this.startLofiMusic();
      });
    } else {
      if (this.externalPlayer) this.externalPlayer.pause();
      this.startLofiMusic();
    }
    this.notifyState();
  }

  public stopMusic() {
    this.isPlaying = false;
    this.stopLofiMusic();
    if (this.externalPlayer) {
      this.externalPlayer.pause();
    }
    if (this.audioElement) {
      this.audioElement.pause();
    }
    this.notifyState();
  }

  private stopLofiMusic() {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public getTrackInfo() {
    return {
      isPlaying: this.isPlaying,
      trackName: this.currentTrackName,
      type: this.audioSourceType,
      volume: this.volume,
    };
  }

  // Interactive sounds
  public playSparkle() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const notes = [587.33, 739.99, 880.0, 1174.66];

    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.06);

      gain.gain.setValueAtTime(0.001, now + idx * 0.06);
      gain.gain.linearRampToValueAtTime(0.06, now + idx * 0.06 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.06 + 0.3);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now + idx * 0.06);
      osc.stop(now + idx * 0.06 + 0.35);
    });
  }

  public playPop() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(680, now + 0.08);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.1);
  }

  public playCelebration() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880, 1108.73, 1318.51];

    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);

      gain.gain.setValueAtTime(0.001, now + idx * 0.08);
      gain.gain.linearRampToValueAtTime(0.12, now + idx * 0.08 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.8);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 0.85);
    });
  }
}

export const soundFx = new SoundManager();
