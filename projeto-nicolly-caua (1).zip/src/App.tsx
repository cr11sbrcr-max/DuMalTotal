import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { MobileFrame } from './components/MobileFrame';
import { FallingHeartsBackground } from './components/FallingHeartsBackground';
import { HeroSection } from './components/HeroSection';
import { TimelineSection } from './components/TimelineSection';
import { FlawsSection } from './components/FlawsSection';
import { FavoritesSection } from './components/FavoritesSection';
import { InteractiveSaudadeMeter } from './components/InteractiveSaudadeMeter';
import { MemoriesSection } from './components/MemoriesSection';
import { WhatILoveSection } from './components/WhatILoveSection';
import { InteractiveEnvelopeLetter } from './components/InteractiveEnvelopeLetter';
import { ProposalSection } from './components/ProposalSection';
import { PhotoManagerModal } from './components/PhotoManagerModal';
import { LightboxModal } from './components/LightboxModal';
import { MusicModal } from './components/MusicModal';
import { YouTubeAudioPlayer } from './components/YouTubeAudioPlayer';
import { usePhotoStorage } from './hooks/usePhotoStorage';
import { PhotoSlotData } from './types';
import { Camera, Music } from 'lucide-react';

export default function App() {
  const {
    photoSlots,
    updatePhoto,
    uploadPhotoFromFile,
    uploadMultipleFiles,
    syncPhotosToServer,
    isSyncing,
    isSynced,
    resetPhoto,
    resetAllPhotos,
  } = usePhotoStorage();

  const [isPhotoManagerOpen, setIsPhotoManagerOpen] = useState(false);
  const [isMusicModalOpen, setIsMusicModalOpen] = useState(false);
  const [activeLightboxPhoto, setActiveLightboxPhoto] = useState<PhotoSlotData | null>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        const progress = window.scrollY / totalHeight;
        setScrollProgress(progress);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToStory = () => {
    const element = document.getElementById('historia');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#faf5ff] text-slate-800 relative selection:bg-purple-200 selection:text-purple-900 overflow-x-hidden">
      {/* Hidden YouTube audio stream player for Pixote */}
      <YouTubeAudioPlayer />

      {/* Falling Hearts in Background */}
      <FallingHeartsBackground />

      {/* Centered Mobile Framing Shell */}
      <MobileFrame scrollProgress={scrollProgress}>
        {/* Top Navbar pinned inside frame */}
        <Navbar
          onOpenPhotoManager={() => setIsPhotoManagerOpen(true)}
          onOpenMusicModal={() => setIsMusicModalOpen(true)}
          scrollProgress={scrollProgress}
        />

        {/* Main Content Journey */}
        <main className="relative z-10 px-3 sm:px-4 pb-12">
          {/* Section 1: Hero */}
          <HeroSection onStartExperience={scrollToStory} />

          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-purple-300 to-transparent mx-auto my-6 rounded-full" />

          {/* Section 2: Nossa História (19.08.2024) */}
          <TimelineSection
            photoSlots={photoSlots}
            onUploadFile={uploadPhotoFromFile}
            onOpenLightbox={(photo) => setActiveLightboxPhoto(photo)}
          />

          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-purple-300 to-transparent mx-auto my-6 rounded-full" />

          {/* Section 3: Os Defeitos do Cauã */}
          <FlawsSection />

          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-purple-300 to-transparent mx-auto my-6 rounded-full" />

          {/* Section 4: As Coisas que Lembram a Nicolly */}
          <FavoritesSection
            photoSlots={photoSlots}
            onUploadFile={uploadPhotoFromFile}
            onOpenLightbox={(photo) => setActiveLightboxPhoto(photo)}
          />

          {/* Interactive Feature: Termômetro de Saudade */}
          <InteractiveSaudadeMeter />

          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-purple-300 to-transparent mx-auto my-6 rounded-full" />

          {/* Section 5: Memórias Reais */}
          <MemoriesSection
            photoSlots={photoSlots}
            onUploadFile={uploadPhotoFromFile}
            onOpenLightbox={(photo) => setActiveLightboxPhoto(photo)}
          />

          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-purple-300 to-transparent mx-auto my-6 rounded-full" />

          {/* Section 6: O Que Eu Ainda Amo em Você */}
          <WhatILoveSection
            photoSlots={photoSlots}
            onUploadFile={uploadPhotoFromFile}
            onOpenLightbox={(photo) => setActiveLightboxPhoto(photo)}
          />

          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-purple-300 to-transparent mx-auto my-6 rounded-full" />

          {/* Section 8: O Que Mudou em Mim (Envelope Interativo da Carta) */}
          <InteractiveEnvelopeLetter />

          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-purple-300 to-transparent mx-auto my-6 rounded-full" />

          {/* Section 9 & 10: O Que Eu Quero & Final */}
          <ProposalSection />
        </main>
      </MobileFrame>

      {/* Floating Bottom Quick Action for Cauã */}
      <aside aria-label="Ações rápidas" className="fixed bottom-4 right-4 z-40 flex items-center gap-2">
        <button
          onClick={() => setIsMusicModalOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-full bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs sm:text-sm shadow-xl shadow-pink-300/80 hover:scale-105 active:scale-95 transition-all cursor-pointer border border-white/30"
          title="Escolher música de fundo"
        >
          <Music className="w-4 h-4" />
          <span className="hidden sm:inline">Música</span>
        </button>

        <button
          onClick={() => setIsPhotoManagerOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs sm:text-sm shadow-xl shadow-purple-300/80 hover:scale-105 active:scale-95 transition-all cursor-pointer border border-white/30"
          title="Colocar fotos reais nossas"
        >
          <Camera className="w-4 h-4" />
          <span className="hidden sm:inline">Colocar Nossas Fotos</span>
          <span className="sm:hidden">Fotos</span>
        </button>
      </aside>

      {/* Modals */}
      <PhotoManagerModal
        isOpen={isPhotoManagerOpen}
        onClose={() => setIsPhotoManagerOpen(false)}
        photoSlots={photoSlots}
        onUploadFile={uploadPhotoFromFile}
        onUploadMultipleFiles={uploadMultipleFiles}
        onResetPhoto={resetPhoto}
        onResetAll={resetAllPhotos}
        onUpdatePhoto={updatePhoto}
        onSyncToServer={syncPhotosToServer}
        isSyncing={isSyncing}
        isSynced={isSynced}
      />

      <MusicModal
        isOpen={isMusicModalOpen}
        onClose={() => setIsMusicModalOpen(false)}
      />

      <LightboxModal
        photo={activeLightboxPhoto}
        onClose={() => setActiveLightboxPhoto(null)}
      />
    </div>
  );
}
