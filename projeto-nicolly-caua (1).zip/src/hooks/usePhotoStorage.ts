import { useState, useEffect } from 'react';
import { PhotoSlotData } from '../types';
import { all14PhotoSlots } from '../data/initialData';

const STORAGE_KEY = 'nicolly_caua_story_photos_v5';

export function usePhotoStorage() {
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSynced, setIsSynced] = useState(false);
  const [photoSlots, setPhotoSlots] = useState<PhotoSlotData[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Merge with all14PhotoSlots in case keys or descriptions were updated
        return all14PhotoSlots.map((init) => {
          const found = parsed.find((p: PhotoSlotData) => p.id === init.id);
          return found ? { ...init, ...found } : init;
        });
      }
    } catch (e) {
      console.error('Error reading photos from localStorage', e);
    }
    return all14PhotoSlots;
  });

  // 1. Fetch server-persisted photos on initial load so any visitor (Nicolly) sees them!
  useEffect(() => {
    let isMounted = true;
    async function loadServerPhotos() {
      try {
        const res = await fetch('/api/photos');
        if (res.ok) {
          const data = await res.json();
          if (data && data.success && Array.isArray(data.photos) && data.photos.length > 0) {
            if (isMounted) {
              setPhotoSlots((prev) => {
                return prev.map((curr) => {
                  const serverMatch = data.photos.find((p: PhotoSlotData) => p.id === curr.id);
                  if (serverMatch && serverMatch.userImage) {
                    return { ...curr, ...serverMatch };
                  }
                  return curr;
                });
              });
              setIsSynced(true);
            }
          }
        }
      } catch (err) {
        console.warn('Could not fetch /api/photos, using local storage state:', err);
      }
    }
    loadServerPhotos();
    return () => {
      isMounted = false;
    };
  }, []);

  // 2. Persist to local browser storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(photoSlots));
    } catch (e) {
      console.warn('Could not save photos to localStorage (quota exceeded or private mode)', e);
    }
  }, [photoSlots]);

  // 3. Sync to server
  const syncPhotosToServer = async (slotsToSync = photoSlots) => {
    try {
      setIsSyncing(true);
      const res = await fetch('/api/photos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ photos: slotsToSync }),
      });
      if (res.ok) {
        setIsSynced(true);
        return true;
      }
    } catch (err) {
      console.warn('Error syncing photos to server:', err);
    } finally {
      setIsSyncing(false);
    }
    return false;
  };

  const updatePhoto = (id: string, updates: Partial<PhotoSlotData>) => {
    setPhotoSlots((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const compressAndConvertFile = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        if (!result) return reject('No result');

        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const maxDim = 1400; // high fidelity
          let width = img.width;
          let height = img.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const compressed = canvas.toDataURL('image/jpeg', 0.90);
            resolve(compressed);
          } else {
            resolve(result);
          }
        };
        img.onerror = () => resolve(result);
        img.src = result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const uploadPhotoFromFile = async (id: string, file: File, caption?: string) => {
    const dataUrl = await compressAndConvertFile(file);
    const updated = photoSlots.map((item) =>
      item.id === id ? { ...item, userImage: dataUrl, ...(caption ? { caption } : {}) } : item
    );
    setPhotoSlots(updated);
    syncPhotosToServer(updated).catch(console.warn);
  };

  const uploadMultipleFiles = async (files: File[]) => {
    let currentList = [...photoSlots];
    for (let i = 0; i < Math.min(files.length, currentList.length); i++) {
      const slot = currentList[i];
      const dataUrl = await compressAndConvertFile(files[i]);
      currentList = currentList.map((item) =>
        item.id === slot.id ? { ...item, userImage: dataUrl } : item
      );
    }
    setPhotoSlots(currentList);
    await syncPhotosToServer(currentList);
  };

  const resetPhoto = (id: string) => {
    const original = all14PhotoSlots.find((p) => p.id === id);
    if (original) {
      const updated = photoSlots.map((item) =>
        item.id === id
          ? {
              ...item,
              userImage: undefined,
              caption: original.caption,
              title: original.title,
              date: original.date,
            }
          : item
      );
      setPhotoSlots(updated);
      syncPhotosToServer(updated).catch(console.warn);
    }
  };

  const resetAllPhotos = () => {
    setPhotoSlots(all14PhotoSlots);
    localStorage.removeItem(STORAGE_KEY);
    syncPhotosToServer(all14PhotoSlots).catch(console.warn);
  };

  return {
    photoSlots,
    updatePhoto,
    uploadPhotoFromFile,
    uploadMultipleFiles,
    syncPhotosToServer,
    isSyncing,
    isSynced,
    resetPhoto,
    resetAllPhotos,
  };
}
