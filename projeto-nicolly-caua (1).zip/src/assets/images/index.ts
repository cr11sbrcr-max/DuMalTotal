// Generated curated theme assets
import kuromiImg from './kuromi_romantic_art_1791244394714.jpg';
import aliceImg from './alice_borderland_cards_1791244520108.jpg';
import princessImg from './princess_frog_magic_1791244603420.jpg';
import coralineImg from './coraline_portal_spiral_1791244558757.jpg';
import arcaneImg from './arcane_hextech_neon_1791244579189.jpg';
import friesImg from './crispy_french_fries_1791244590778.jpg';
import coupleSleepImg from './couple_cuddled_sleep_1791244691484.jpg';
import curlyHairImg from './girl_curly_hair_sun_1791244711011.jpg';

export const themeImages = {
  kuromi: kuromiImg,
  alice: aliceImg,
  princess: princessImg,
  coraline: coralineImg,
  arcane: arcaneImg,
  fries: friesImg,
  coupleSleep: coupleSleepImg,
  curlyHair: curlyHairImg,
};
