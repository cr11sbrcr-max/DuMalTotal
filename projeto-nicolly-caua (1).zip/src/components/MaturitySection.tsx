import React from 'react';
import { RefreshCw, CheckCircle, ShieldCheck, HeartHandshake, Eye } from 'lucide-react';

export const MaturitySection: React.FC = () => {
  return (
    <section id="amadurecimento" className="relative py-20 px-4 max-w-4xl mx-auto">
      {/* Section Header */}
      <div className="text-center mb-14">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/60 border border-purple-500/30 text-xs text-indigo-300 font-mono mb-3">
          <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
          <span>CAPÍTULO 07 · PAPO RETO E MATURIDADE</span>
        </div>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight font-display">
          O Que Mudou em Mim
        </h2>
        <p className="mt-3 max-w-xl mx-auto text-purple-200/80 text-sm sm:text-base">
          Promessa vazia não adianta de nada se a cabeça continuar a mesma. Aqui é a minha verdade,
          sem filtro e sem orgulho bobo.
        </p>
      </div>

      {/* Main Letter Card */}
      <div className="bg-gradient-to-br from-[#160c2c] via-[#110724] to-[#0d051c] p-7 sm:p-10 rounded-3xl border border-indigo-500/30 shadow-2xl relative text-left">
        <div className="space-y-6 text-base sm:text-lg text-purple-100 leading-relaxed font-light">
          <p className="font-semibold text-white text-lg sm:text-xl">
            Eu não quero fingir que nada aconteceu.
          </p>

          <p>
            Não quero apagar o que deu errado, nem passar pano pros meus momentos de chatice,
            teimosia ou desligamento. Não quero voltar no tempo e fingir que eu era perfeito,
            porque eu definitivamente <span className="font-mono text-pink-300 font-normal">não era kkkkkkkkk</span>.
          </p>

          <div className="p-5 rounded-2xl bg-purple-950/50 border-l-4 border-pink-500 my-6">
            <p className="text-sm sm:text-base text-purple-100 italic">
              “Queria que a gente se reconhecesse: a nova Nicolly e o novo Cauã. Duas pessoas que
              aprenderam com a vida, respeitando um ao outro apesar do que ambos não coincidirem.”
            </p>
          </div>

          <p>
            O término foi um soco no estômago, mas também foi o que me fez cair na real. Eu aprendi
            que <strong className="text-pink-300 font-bold">amar alguém não é só sobre sentir muito</strong>.
            Sentir muito qualquer um sente. O amor de verdade é saber demonstrar, cuidar, ouvir com
            atenção, compreender nos dias difíceis e estar verdadeiramente presente.
          </p>

          <p className="text-purple-200/90">
            Eu não sou mais aquele menino inseguro que se fechava numa bolha. Se hoje eu coloco minha
            cara a tapa aqui, é porque eu tenho a tranquilidade de quem amadureceu e sabe o que quer.
          </p>
        </div>

        {/* Pillars Checklist */}
        <div className="mt-10 pt-8 border-t border-purple-900/60 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-2xl bg-black/30 border border-purple-800/30 flex items-start gap-3">
            <Eye className="w-5 h-5 text-pink-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-bold text-white">Presença Real</h4>
              <p className="text-xs text-purple-300/80 mt-1">Estar atento a você, sem viver no mundo da lua.</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-black/30 border border-purple-800/30 flex items-start gap-3">
            <HeartHandshake className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-bold text-white">Diálogo Aberto</h4>
              <p className="text-xs text-purple-300/80 mt-1">Conversar sem bico, sem paranoia e com respeito.</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-black/30 border border-purple-800/30 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-bold text-white">Cuidado Leve</h4>
              <p className="text-xs text-purple-300/80 mt-1">Aquele chamego tranquilo que a gente sempre teve.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
