import React, { useEffect, useRef } from 'react';

interface HeartParticle {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  swayAmplitude: number;
  swaySpeed: number;
  swayOffset: number;
  opacity: number;
  color: string;
  rotation: number;
  rotationSpeed: number;
}

interface FallingHeartsBackgroundProps {
  className?: string;
  isAbsolute?: boolean;
}

export const FallingHeartsBackground: React.FC<FallingHeartsBackgroundProps> = ({
  className = '',
  isAbsolute = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const getDimensions = () => {
      if (isAbsolute && canvas.parentElement) {
        return {
          w: canvas.parentElement.clientWidth || window.innerWidth,
          h: canvas.parentElement.clientHeight || window.innerHeight,
        };
      }
      return {
        w: window.innerWidth,
        h: window.innerHeight,
      };
    };

    let { w: width, h: height } = getDimensions();
    canvas.width = width;
    canvas.height = height;

    const handleResize = () => {
      if (!canvas) return;
      const dims = getDimensions();
      width = canvas.width = dims.w;
      height = canvas.height = dims.h;
    };

    window.addEventListener('resize', handleResize);

    // Also observe parent resize if isAbsolute
    let resizeObserver: ResizeObserver | null = null;
    if (isAbsolute && canvas.parentElement && typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => {
        handleResize();
      });
      resizeObserver.observe(canvas.parentElement);
    }

    const colors = [
      'rgba(236, 72, 153, 0.70)', // pink-500
      'rgba(244, 114, 182, 0.75)', // pink-400
      'rgba(219, 39, 119, 0.65)',  // pink-600
      'rgba(168, 85, 247, 0.65)',  // purple-500
      'rgba(192, 132, 252, 0.70)', // purple-400
      'rgba(225, 29, 72, 0.60)',   // rose-600
      'rgba(249, 168, 212, 0.85)', // pink-300
    ];

    const heartCount = Math.max(18, Math.min(36, Math.floor(width / 18)));
    const hearts: HeartParticle[] = [];

    const createHeart = (initialY = -25): HeartParticle => ({
      x: Math.random() * width,
      y: initialY,
      size: Math.random() * 14 + 10, // 10px to 24px
      speedY: Math.random() * 1.3 + 0.7,
      speedX: (Math.random() - 0.5) * 0.5,
      swayAmplitude: Math.random() * 1.8 + 0.8,
      swaySpeed: Math.random() * 0.02 + 0.012,
      swayOffset: Math.random() * Math.PI * 2,
      opacity: Math.random() * 0.45 + 0.35,
      color: colors[Math.floor(Math.random() * colors.length)],
      rotation: (Math.random() - 0.5) * 0.4,
      rotationSpeed: (Math.random() - 0.5) * 0.015,
    });

    for (let i = 0; i < heartCount; i++) {
      hearts.push(createHeart(Math.random() * height));
    }

    const drawHeart = (
      x: number,
      y: number,
      size: number,
      color: string,
      rotation: number
    ) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rotation);
      ctx.fillStyle = color;

      // Draw SVG-like smooth cubic bezier heart
      ctx.beginPath();
      const topCurveHeight = size * 0.3;
      ctx.moveTo(0, topCurveHeight);
      // top left curve
      ctx.bezierCurveTo(
        -size / 2,
        -size / 2,
        -size,
        topCurveHeight / 3,
        0,
        size
      );
      // top right curve
      ctx.bezierCurveTo(
        size,
        topCurveHeight / 3,
        size / 2,
        -size / 2,
        0,
        topCurveHeight
      );
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    };

    let tick = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      tick++;

      hearts.forEach((heart, idx) => {
        heart.y += heart.speedY;
        heart.x += Math.sin(tick * heart.swaySpeed + heart.swayOffset) * heart.swayAmplitude + heart.speedX;
        heart.rotation += heart.rotationSpeed;

        if (heart.y > height + 30) {
          hearts[idx] = createHeart(-20);
        }

        drawHeart(heart.x, heart.y, heart.size, heart.color, heart.rotation);
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (resizeObserver) resizeObserver.disconnect();
      cancelAnimationFrame(animationFrameId);
    };
  }, [isAbsolute]);

  return (
    <canvas
      ref={canvasRef}
      className={
        isAbsolute
          ? `w-full h-full pointer-events-none z-0 ${className}`
          : `fixed inset-0 pointer-events-none z-0 opacity-75 ${className}`
      }
      aria-hidden="true"
    />
  );
};
