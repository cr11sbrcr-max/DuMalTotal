import React, { useEffect, useRef, useState } from 'react';
import { soundFx } from '../utils/audio';

// YouTube Video ID for Pixote - Mande Um Sinal (15 Anos Ao Vivo)
export const OFFICIAL_PIXOTE_VIDEO_ID = 'k_j_C30K2v8';
export const OFFICIAL_TRACK_TITLE = 'Pixote - Mande Um Sinal (15 Anos - Ao Vivo)';

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: (() => void) | undefined;
    pixoteYtPlayer: any;
  }
}

interface YouTubeAudioPlayerProps {
  onReady?: () => void;
}

export const YouTubeAudioPlayer: React.FC<YouTubeAudioPlayerProps> = ({ onReady }) => {
  const playerRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlayerReady, setIsPlayerReady] = useState(false);

  useEffect(() => {
    // 1. Ensure YouTube IFrame API is loaded
    if (!window.YT || !window.YT.Player) {
      const existingScript = document.getElementById('youtube-iframe-api');
      if (!existingScript) {
        const tag = document.createElement('script');
        tag.id = 'youtube-iframe-api';
        tag.src = 'https://www.youtube.com/iframe_api';
        const firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag?.parentNode?.insertBefore(tag, firstScriptTag);
      }

      const prevCallback = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (prevCallback) prevCallback();
        initPlayer();
      };
    } else {
      initPlayer();
    }

    function initPlayer() {
      if (playerRef.current) return;
      try {
        playerRef.current = new window.YT.Player('pixote-hidden-audio-frame', {
          height: '1',
          width: '1',
          videoId: OFFICIAL_PIXOTE_VIDEO_ID,
          playerVars: {
            autoplay: 0,
            controls: 0,
            disablekb: 1,
            fs: 0,
            loop: 1,
            playlist: OFFICIAL_PIXOTE_VIDEO_ID,
            modestbranding: 1,
            rel: 0,
            playsinline: 1,
            origin: window.location.origin,
          },
          events: {
            onReady: (event: any) => {
              window.pixoteYtPlayer = event.target;
              event.target.setVolume(Math.round(soundFx.getVolume() * 100));
              setIsPlayerReady(true);
              soundFx.registerExternalPlayer({
                play: () => {
                  try {
                    event.target.playVideo();
                  } catch (e) {
                    console.warn('YT play failed', e);
                  }
                },
                pause: () => {
                  try {
                    event.target.pauseVideo();
                  } catch (e) {
                    console.warn('YT pause failed', e);
                  }
                },
                setVolume: (vol: number) => {
                  try {
                    event.target.setVolume(Math.round(vol * 100));
                  } catch (e) {
                    console.warn('YT volume set failed', e);
                  }
                },
              });
              if (onReady) onReady();
            },
            onStateChange: (event: any) => {
              // YT.PlayerState.PLAYING = 1, PAUSED = 2, ENDED = 0
              if (event.data === 1) {
                soundFx.notifyExternalPlaybackState(true);
              } else if (event.data === 2 || event.data === 0) {
                soundFx.notifyExternalPlaybackState(false);
              }
            },
          },
        });
      } catch (err) {
        console.warn('Could not initialize YouTube Player:', err);
      }
    }

    return () => {
      // Keep player intact for page lifetime
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed -bottom-96 -left-96 pointer-events-none opacity-0 select-none overflow-hidden"
      aria-hidden="true"
    >
      <div id="pixote-hidden-audio-frame" />
    </div>
  );
};
