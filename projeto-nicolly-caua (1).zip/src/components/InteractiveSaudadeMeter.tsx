import React, { useState } from 'react';
import { Heart, Sparkles, Flame, Smile } from 'lucide-react';
import { soundFx } from '../utils/audio';

export const InteractiveSaudadeMeter: React.FC = () => {
  const [level, setLevel] = useState<number>(85);

  const getCommentary = (val: number) => {
    if (val === 0) {
      return {
        title: '0% de Saudade? 🤨',
        text: 'Mentira deslavada kkkkkkk nem você acredita nisso! Anda, arrasta isso pra frente.',
        badge: 'Negação Nível Máximo',
        color: 'text-slate-600 bg-slate-100',
      };
    }
    if (val <= 25) {
      return {
        title: '25% - Pelo menos lembrou rs',
        text: 'Já é um começo! Pelo menos passou pela sua cabeça aquele abraço bom.',
        badge: 'Esquentando os motores',
        color: 'text-purple-700 bg-purple-100',
      };
    }
    if (val <= 50) {
      return {
        title: '50% - Meio Caminho Andado ✨',
        text: 'Metade do caminho... aqui já cabe um zap com piada interna ou um convite pra comer batata frita.',
        badge: 'Quase aceitando',
        color: 'text-indigo-700 bg-indigo-100',
      };
    }
    if (val <= 85) {
      return {
        title: '85% - Tá Forte Hein! 💜',
        text: 'Lembra do cheiro, do colinho, das risadas idiotas e daquele silêncio que só a gente tinha.',
        badge: 'Coração Amolecendo',
        color: 'text-fuchsia-700 bg-fuchsia-100',
      };
    }
    return {
      title: '100%+ - OVERDOSE DE SAUDADE! 🔥❤️',
      text: 'ACABOU O ORGULHO! Vem logo me dar um abraço bem demorado e nunca mais soltar!',
      badge: 'Vem de Zap Imediatamente',
      color: 'text-pink-700 bg-pink-100',
    };
  };

  const current = getCommentary(level);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setLevel(val);
    if (val % 20 === 0) {
      soundFx.playPop();
    }
  };

  return (
    <div className="my-10 w-full p-5 sm:p-6 rounded-3xl bg-white border border-purple-200 shadow-lg shadow-purple-100/60 text-center relative overflow-hidden">
      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-100 border border-purple-200 text-xs text-purple-700 font-semibold mb-3">
        <Flame className="w-3.5 h-3.5 text-pink-500" />
        <span>INTERATIVO · TESTE DE SINCERIDADE</span>
      </div>

      <h3 className="text-xl sm:text-2xl font-bold text-purple-950 font-display">
        Medidor de Saudade da Nicolly
      </h3>
      <p className="text-xs sm:text-sm text-purple-700/80 mt-1 mb-6">
        Seja sincera: quanto de saudade das nossas bobagens ainda mora aí dentro?
      </p>

      {/* Big Display Level */}
      <div className="mb-4">
        <span className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-700 to-pink-600 font-display">
          {level}%
        </span>
      </div>

      {/* Slider Control */}
      <div className="px-4 mb-6">
        <input
          type="range"
          min="0"
          max="100"
          value={level}
          onChange={handleChange}
          className="w-full h-3 bg-purple-100 rounded-lg appearance-none cursor-pointer accent-purple-600 focus:outline-none"
        />
        <div className="flex justify-between text-[11px] font-mono text-purple-500 font-semibold mt-1">
          <span>0% (Nem fudendo)</span>
          <span>50% (Um tiquinho)</span>
          <span>100% (Muita saudade ❤️)</span>
        </div>
      </div>

      {/* Reaction Box */}
      <div className="p-4 rounded-2xl bg-purple-50/80 border border-purple-200 text-left transition-all">
        <div className="flex items-center justify-between mb-1">
          <h4 className="text-sm font-bold text-purple-900">{current.title}</h4>
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${current.color}`}>
            {current.badge}
          </span>
        </div>
        <p className="text-xs sm:text-sm text-purple-800 leading-relaxed font-light">
          {current.text}
        </p>
      </div>
    </div>
  );
};
