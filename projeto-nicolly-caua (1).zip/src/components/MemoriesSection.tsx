import React from 'react';
import { Image as ImageIcon } from 'lucide-react';
import { PhotoSlotData } from '../types';
import { PhotoCard } from './PhotoCard';

interface MemoriesSectionProps {
  photoSlots: PhotoSlotData[];
  onUploadFile: (id: string, file: File) => void;
  onOpenLightbox: (photo: PhotoSlotData) => void;
}

export const MemoriesSection: React.FC<MemoriesSectionProps> = ({
  photoSlots,
  onUploadFile,
  onOpenLightbox,
}) => {
  const memoryPhotos = photoSlots.filter((p) => p.section === 'memorias');

  return (
    <section id="memorias" className="relative py-12 sm:py-16 px-1 sm:px-2 w-full">
      {/* Section Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-100 border border-purple-200 text-xs text-purple-700 font-semibold mb-2.5">
          <ImageIcon className="w-3.5 h-3.5 text-pink-500" />
          <span>CAPÍTULO 04 · NOSSAS MEMÓRIAS REAIS</span>
        </div>
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-purple-950 tracking-tight font-display">
          Memórias de Nós Dois
        </h2>
        <p className="mt-2 text-purple-800/80 text-xs sm:text-sm font-light">
          A leveza de um relacionamento que não precisava de esforço pra ser bom. As nossas fotos,
          nossas risadas bobas e o quanto a gente combinava.
        </p>
      </div>

      {/* Memories Grid in Polaroid Layout - Fileiras de Dois */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-4 w-full mx-auto">
        {memoryPhotos.map((photo, index) => {
          const rotations = ['rotate-[-1deg]', 'rotate-[1deg]', 'rotate-[-0.5deg]', 'rotate-[0.5deg]'];
          const rot = rotations[index % rotations.length];

          return (
            <div key={photo.id} className="w-full">
              <PhotoCard
                photo={photo}
                onUploadFile={onUploadFile}
                onOpenLightbox={onOpenLightbox}
                rotate={rot}
              />
            </div>
          );
        })}
      </div>
    </section>
  );
};
