import React, { useRef, useState } from 'react';
import { X, Upload, RotateCcw, Check, Sparkles, Camera, Heart, HelpCircle } from 'lucide-react';
import { PhotoSlotData } from '../types';
import { soundFx } from '../utils/audio';

interface PhotoManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  photoSlots: PhotoSlotData[];
  onUploadFile: (id: string, file: File, caption?: string) => Promise<void>;
  onUploadMultipleFiles: (files: File[]) => Promise<void>;
  onResetPhoto: (id: string) => void;
  onResetAll: () => void;
  onUpdatePhoto: (id: string, updates: Partial<PhotoSlotData>) => void;
  onSyncToServer?: () => Promise<boolean>;
  isSyncing?: boolean;
  isSynced?: boolean;
}

export const PhotoManagerModal: React.FC<PhotoManagerModalProps> = ({
  isOpen,
  onClose,
  photoSlots,
  onUploadFile,
  onUploadMultipleFiles,
  onResetPhoto,
  onResetAll,
  onUpdatePhoto,
  onSyncToServer,
  isSyncing,
  isSynced,
}) => {
  const [activeSlotId, setActiveSlotId] = useState<string | null>(null);
  const [isUploadingBatch, setIsUploadingBatch] = useState(false);
  const [statusFeedback, setStatusFeedback] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const batchInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setStatusFeedback(msg);
    setTimeout(() => setStatusFeedback(null), 3500);
  };

  const handleSelectSlotForUpload = (id: string) => {
    setActiveSlotId(id);
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && activeSlotId) {
      soundFx.playPop();
      await onUploadFile(activeSlotId, e.target.files[0]);
      setActiveSlotId(null);
    }
  };

  const handleBatchFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    setIsUploadingBatch(true);
    soundFx.playSparkle();

    const files = Array.from(e.target.files);
    await onUploadMultipleFiles(files);

    setIsUploadingBatch(false);
    soundFx.playCelebration();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-purple-950/60 backdrop-blur-md animate-fade-in">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />
      <input
        type="file"
        ref={batchInputRef}
        onChange={handleBatchFileChange}
        accept="image/*"
        multiple
        className="hidden"
      />

      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-t-[32px] sm:rounded-3xl bg-white border border-purple-200 shadow-2xl text-slate-800 overflow-hidden">
        {/* Mobile Pull Handle */}
        <div className="w-12 h-1.5 bg-purple-200 rounded-full mx-auto my-2 sm:hidden shrink-0" />

        {/* Header */}
        <div className="px-5 sm:px-6 py-4 sm:py-5 border-b border-purple-100 flex items-center justify-between bg-gradient-to-r from-purple-50 via-white to-pink-50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-purple-100 text-purple-700">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-purple-950 font-display">
                Suas Fotos Reais com a Nicolly
              </h3>
              <p className="text-xs text-purple-700/80">
                Cada foto e momento especial tem seu espaço exato reservado abaixo
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-purple-100 text-purple-500 hover:text-purple-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Notification feedback toast */}
          {statusFeedback && (
            <div className="p-3.5 rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-semibold flex items-center gap-2 animate-fade-in shadow-sm">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{statusFeedback}</span>
            </div>
          )}

          {/* Server Sync / Publish Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-purple-50 border border-emerald-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${isSynced ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
                <span className="text-xs font-bold text-slate-800">
                  {isSynced ? '✓ Fotos Sincronizadas no Servidor do Site' : 'Sincronização com o Site'}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed font-light">
                {isSynced
                  ? 'Todas as fotos estão gravadas no servidor! Quando a Nicolly abrir o link no celular dela, verá tudo automaticamente.'
                  : 'Suba as fotos abaixo pelo botão de seleção. Elas são salvas tanto no seu celular quanto no servidor do site!'}
              </p>
            </div>

            {onSyncToServer && (
              <button
                onClick={async () => {
                  soundFx.playSparkle();
                  const success = await onSyncToServer();
                  if (success) {
                    soundFx.playCelebration();
                    showToast('✓ Fotos publicadas com sucesso no servidor do site! A Nicolly já pode abrir.');
                  } else {
                    showToast('Fotos salvas na memória local do seu navegador!');
                  }
                }}
                disabled={isSyncing}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 transition-all active:scale-95 shrink-0 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isSyncing ? 'Gravando no Servidor...' : 'Publicar no Servidor Agora'}</span>
              </button>
            )}
          </div>

          {/* Batch Upload Hero Banner */}
          <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-purple-100 via-fuchsia-50 to-pink-100 border border-purple-200 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
            <div className="text-left space-y-1">
              <div className="flex items-center gap-2 text-purple-900 font-bold text-sm sm:text-base">
                <Sparkles className="w-4 h-4 text-pink-500" />
                <span>Carregar Todas as 14 Fotos de Uma Vez</span>
              </div>
              <p className="text-xs sm:text-sm text-purple-800/80 leading-relaxed max-w-xl">
                Clique ao lado e selecione as fotos do seu celular/computador. O site preenche
                automaticamente os 14 espaços correspondentes mantendo qualidade original e sem alterar nada!
              </p>
            </div>
            <button
              onClick={() => batchInputRef.current?.click()}
              disabled={isUploadingBatch}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white font-bold text-xs sm:text-sm shadow-lg shadow-purple-200 flex items-center justify-center gap-2 transition-all active:scale-95 shrink-0 disabled:opacity-50 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>{isUploadingBatch ? 'Colocando Fotos...' : 'Selecionar Várias Fotos'}</span>
            </button>
          </div>

          {/* Slots Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
            {photoSlots.map((slot) => {
              const currentImg = slot.userImage || slot.defaultImage;
              const isCustom = Boolean(slot.userImage);

              return (
                <div
                  key={slot.id}
                  className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 ${
                    isCustom
                      ? 'bg-purple-50/40 border-purple-300 shadow-sm'
                      : 'bg-white border-purple-100 hover:border-purple-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="relative w-16 h-20 rounded-xl overflow-hidden bg-purple-50 shrink-0 border border-purple-200 shadow-xs">
                      <img
                        src={currentImg}
                        alt={slot.title}
                        className="w-full h-full object-cover"
                      />
                      {isCustom && (
                        <div className="absolute top-1 right-1 p-0.5 rounded-full bg-emerald-500 text-white shadow-xs">
                          <Check className="w-2.5 h-2.5" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0 text-left">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-purple-600 font-bold uppercase tracking-wider">
                          {slot.tag || `Foto ${slot.order}`}
                        </span>
                        {isCustom ? (
                          <span className="text-[10px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold">
                            Foto Real Ativa
                          </span>
                        ) : (
                          <span className="text-[10px] bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full font-medium">
                            Padrão
                          </span>
                        )}
                      </div>
                      <h4 className="text-sm font-bold text-purple-950 mt-0.5 truncate">{slot.title}</h4>
                      <p className="text-[11px] text-purple-600 font-mono mt-0.5 truncate">
                        {slot.suggestedOriginal}
                      </p>
                    </div>
                  </div>

                  {/* Caption Editor */}
                  <div className="text-left">
                    <label className="block text-[11px] text-purple-700 font-medium mb-1">
                      Legenda da Foto:
                    </label>
                    <textarea
                      value={slot.caption}
                      onChange={(e) => onUpdatePhoto(slot.id, { caption: e.target.value })}
                      rows={2}
                      className="w-full text-xs p-2.5 rounded-xl bg-purple-50/50 border border-purple-200 text-purple-900 placeholder-purple-400 focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  {/* Action buttons */}
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => handleSelectSlotForUpload(slot.id)}
                      className="flex-1 py-1.5 px-3 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-900 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 border border-purple-200"
                    >
                      <Upload className="w-3.5 h-3.5 text-purple-600" />
                      <span>{isCustom ? 'Substituir Foto' : 'Inserir Esta Foto'}</span>
                    </button>

                    {isCustom && (
                      <button
                        onClick={() => onResetPhoto(slot.id)}
                        className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                        title="Restaurar padrão"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-purple-100 flex flex-col sm:flex-row items-center justify-between gap-3 bg-purple-50/50">
          <div className="flex items-center gap-3">
            <button
              onClick={onResetAll}
              className="text-xs text-purple-600 hover:text-purple-900 underline transition-colors cursor-pointer"
            >
              Restaurar ilustrações originais
            </button>
            <span className="text-purple-300 hidden sm:inline">|</span>
            <button
              onClick={() => {
                const customOnly = photoSlots
                  .filter((p) => Boolean(p.userImage))
                  .map((p) => ({ id: p.id, title: p.title, image: p.userImage }));
                if (customOnly.length === 0) {
                  showToast('Nenhuma foto personalizada adicionada ainda.');
                  return;
                }
                navigator.clipboard.writeText(JSON.stringify(customOnly));
                soundFx.playCelebration();
                showToast(`Copiado! ${customOnly.length} fotos salvas na área de transferência.`);
              }}
              className="text-xs font-semibold text-pink-600 hover:text-pink-800 transition-colors cursor-pointer"
              title="Copiar dados das fotos para fixar no código"
            >
              📋 Copiar fotos para backup
            </button>
          </div>

          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer"
          >
            Pronto, Salvar e Ver Site
          </button>
        </div>
      </div>
    </div>
  );
};
