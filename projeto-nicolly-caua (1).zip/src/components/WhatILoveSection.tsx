import React from 'react';
import { Sparkles, Heart, Crown, Flame, Zap, HeartHandshake } from 'lucide-react';
import { loveReasons } from '../data/initialData';
import { PhotoSlotData } from '../types';
import { PhotoCard } from './PhotoCard';

interface WhatILoveSectionProps {
  photoSlots: PhotoSlotData[];
  onUploadFile: (id: string, file: File) => void;
  onOpenLightbox: (photo: PhotoSlotData) => void;
}

export const WhatILoveSection: React.FC<WhatILoveSectionProps> = ({
  photoSlots,
  onUploadFile,
  onOpenLightbox,
}) => {
  const lovePhotos = photoSlots.filter((p) => p.section === 'amor');

  return (
    <section id="o-que-amo" className="relative py-12 sm:py-16 px-1 sm:px-2 w-full">
      {/* Section Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-100 border border-pink-200 text-xs text-pink-700 font-semibold mb-2.5">
          <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-500" />
          <span>CAPÍTULO 05 · DETALHES INESQUECÍVEIS</span>
        </div>
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-purple-950 tracking-tight font-display">
          O Que Eu Ainda Amo em Você
        </h2>
        <p className="mt-2 text-purple-800/80 text-xs sm:text-sm font-light">
          O tempo passou, mas a minha admiração por cada detalhe seu só aumentou.
        </p>
      </div>

      {/* 2 Special Dedicated Photos for Beauty & Smile - Fileira de Dois */}
      {lovePhotos.length > 0 && (
        <div className="w-full grid grid-cols-2 gap-2.5 sm:gap-4 mb-12 mx-auto">
          {lovePhotos.map((photo, index) => (
            <div key={photo.id} className="w-full">
              <PhotoCard
                photo={photo}
                onUploadFile={onUploadFile}
                onOpenLightbox={onOpenLightbox}
                rotate={index === 0 ? '-rotate-1' : 'rotate-1'}
              />
            </div>
          ))}
        </div>
      )}

      {/* Feature List Cards */}
      <div className="grid grid-cols-1 gap-4 w-full">
        {loveReasons.map((item, index) => (
          <div
            key={item.title}
            className="bg-white p-6 sm:p-8 rounded-3xl border border-purple-200 shadow-md shadow-purple-50 hover:shadow-xl hover:shadow-purple-100 transition-all text-left flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono font-bold text-purple-600 uppercase tracking-wider">
                  0{index + 1} · {item.subtitle}
                </span>
                <Sparkles className="w-4 h-4 text-pink-400" />
              </div>

              <h3 className="text-2xl font-bold text-purple-950 mb-2 font-display">
                {item.title}
              </h3>

              <p className="text-sm text-purple-900/80 leading-relaxed font-light mb-4">
                {item.text}
              </p>
            </div>

            <div className="pt-3 border-t border-purple-100">
              <p className="font-handwriting text-lg text-purple-800 font-bold">
                "{item.quote}"
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
