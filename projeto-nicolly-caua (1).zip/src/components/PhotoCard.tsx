import React, { useRef } from 'react';
import { Camera, Calendar, ZoomIn, Heart } from 'lucide-react';
import { PhotoSlotData } from '../types';
import { soundFx } from '../utils/audio';

interface PhotoCardProps {
  photo: PhotoSlotData;
  onUploadFile?: (id: string, file: File) => void;
  onOpenLightbox?: (photo: PhotoSlotData) => void;
  rotate?: string;
  className?: string;
  showUploadBadge?: boolean;
}

export const PhotoCard: React.FC<PhotoCardProps> = ({
  photo,
  onUploadFile,
  onOpenLightbox,
  rotate = 'rotate-0',
  className = '',
  showUploadBadge = true,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const activeImage = photo.userImage || photo.defaultImage;
  const isCustom = Boolean(photo.userImage);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && onUploadFile) {
      soundFx.playPop();
      onUploadFile(photo.id, e.target.files[0]);
    }
  };

  return (
    <div
      className={`group relative bg-white p-2.5 sm:p-3.5 pb-3 sm:pb-4 rounded-xl sm:rounded-2xl border border-purple-200/90 shadow-md shadow-purple-100/70 hover:shadow-xl hover:shadow-purple-200/80 transition-all duration-300 hover:-translate-y-1 ${rotate} ${className}`}
    >
      {/* Decorative Washi Tape on top */}
      <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-10 sm:w-14 h-3 sm:h-4 bg-purple-200/70 rounded-xs -rotate-1 shadow-xs pointer-events-none z-10" />

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Photo Frame Container */}
      <div className="relative aspect-[4/5] w-full overflow-hidden rounded-lg sm:rounded-xl bg-purple-50">
        <img
          src={activeImage}
          alt={photo.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />

        {/* Subtle gradient vignette at bottom */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-black/10 pointer-events-none" />

        {/* Tag on Top */}
        <div className="absolute top-1.5 sm:top-2.5 left-1.5 sm:left-2.5 px-1.5 sm:px-2.5 py-0.5 rounded-full bg-white/90 backdrop-blur-md border border-purple-200 text-[8px] sm:text-[10px] uppercase tracking-wider font-bold text-purple-800 shadow-sm max-w-[65%] truncate">
          {photo.tag || `Foto ${photo.order}`}
        </div>

        {/* Action Controls */}
        <div className="absolute top-1.5 sm:top-2.5 right-1.5 sm:right-2.5 flex items-center gap-1 sm:gap-1.5 opacity-90 sm:opacity-0 group-hover:opacity-100 transition-opacity">
          {showUploadBadge && onUploadFile && (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-1 sm:p-1.5 rounded-md sm:rounded-lg bg-white/95 hover:bg-purple-600 hover:text-white text-purple-900 border border-purple-200 backdrop-blur-md transition-all active:scale-90 shadow-sm cursor-pointer"
              title="Trocar por foto real nossa"
            >
              <Camera className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            </button>
          )}

          {onOpenLightbox && (
            <button
              onClick={() => {
                soundFx.playSparkle();
                onOpenLightbox(photo);
              }}
              className="p-1 sm:p-1.5 rounded-md sm:rounded-lg bg-white/95 hover:bg-pink-600 hover:text-white text-purple-900 border border-purple-200 backdrop-blur-md transition-all active:scale-90 shadow-sm cursor-pointer"
              title="Ampliar foto"
            >
              <ZoomIn className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            </button>
          )}
        </div>

        {/* Bottom overlay info inside image */}
        <div className="absolute bottom-1.5 sm:bottom-2.5 left-1.5 sm:left-2.5 right-1.5 sm:right-2.5 text-left pointer-events-none text-white drop-shadow-md">
          {photo.date && (
            <div className="flex items-center gap-1 text-[9px] sm:text-[11px] font-mono text-purple-200 mb-0.5 truncate">
              <Calendar className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-pink-300 shrink-0" />
              <span className="truncate">{photo.date}</span>
            </div>
          )}
          <h4 className="text-[11px] sm:text-sm font-bold tracking-tight text-white leading-tight line-clamp-2">
            {photo.title}
          </h4>
        </div>
      </div>

      {/* Caption text below image (Polaroid scrapbook style) */}
      <div className="mt-2 sm:mt-3 text-left px-0.5 sm:px-1">
        <p className="font-handwriting text-xs sm:text-base md:text-lg text-purple-950 leading-tight line-clamp-2">
          "{photo.caption}"
        </p>

        {isCustom ? (
          <span className="inline-flex items-center gap-1 text-[8px] sm:text-[10px] text-emerald-600 font-semibold font-mono mt-1">
            <Heart className="w-2.5 h-2.5 fill-emerald-500 text-emerald-500" />
            Foto Real de Vocês
          </span>
        ) : (
          <span className="block text-[8px] sm:text-[10px] text-purple-400 font-mono mt-1 truncate">
            {photo.suggestedOriginal}
          </span>
        )}
      </div>
    </div>
  );
};
