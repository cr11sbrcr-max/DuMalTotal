import React, { useState } from 'react';
import { Sparkles, Utensils, Heart, Gamepad2, Film, Ghost, Play, Camera } from 'lucide-react';
import { initialFavorites } from '../data/initialData';
import { FavoriteItem, PhotoSlotData } from '../types';
import { soundFx } from '../utils/audio';

interface FavoritesSectionProps {
  photoSlots: PhotoSlotData[];
  onUploadFile: (id: string, file: File) => void;
  onOpenLightbox: (photo: PhotoSlotData) => void;
}

export const FavoritesSection: React.FC<FavoritesSectionProps> = ({
  photoSlots,
  onUploadFile,
  onOpenLightbox,
}) => {
  const [activeEasterEgg, setActiveEasterEgg] = useState<string | null>(null);
  const [friesCount, setFriesCount] = useState<number>(0);
  const [hasKetchup, setHasKetchup] = useState<boolean>(true);
  const [hasMayo, setHasMayo] = useState<boolean>(true);

  const handleEasterEgg = (item: FavoriteItem) => {
    soundFx.playSparkle();
    if (item.id === 'batata_frita') {
      setFriesCount((prev) => prev + 1);
    }
    setActiveEasterEgg(activeEasterEgg === item.id ? null : item.id);
  };

  const getSlotForFavorite = (slotId: string) => {
    return photoSlots.find((p) => p.id === slotId);
  };

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'kuromi':
        return <Ghost className="w-3.5 h-3.5 text-purple-600" />;
      case 'alice_borderland':
        return <Gamepad2 className="w-3.5 h-3.5 text-indigo-600" />;
      case 'princesa_sapo':
        return <Heart className="w-3.5 h-3.5 text-emerald-600" />;
      case 'coraline':
        return <Sparkles className="w-3.5 h-3.5 text-fuchsia-600" />;
      case 'arcane':
        return <Play className="w-3.5 h-3.5 text-blue-600" />;
      case 'batata_frita':
        return <Utensils className="w-3.5 h-3.5 text-amber-600" />;
      default:
        return <Film className="w-3.5 h-3.5 text-pink-600" />;
    }
  };

  return (
    <section id="coisas-nicolly" className="relative py-12 sm:py-16 px-1 sm:px-2 w-full">
      {/* Section Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-100 border border-purple-200 text-xs text-purple-700 font-semibold mb-2.5">
          <Sparkles className="w-3.5 h-3.5 text-pink-500" />
          <span>CAPÍTULO 03 · SEU MUNDINHO PARTICULAR</span>
        </div>
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-purple-950 tracking-tight font-display">
          As Coisas que Lembram Você
        </h2>
        <p className="mt-2 text-purple-800/80 text-xs sm:text-sm font-light">
          Tudo que você ama tem a sua identidade: um mistério instigante, muito bom gosto, uma marra
          irresistível e um prato de batata frita bem caprichado.
        </p>
      </div>

      {/* Cards Grid - Fileiras de dois (grid-cols-2) */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-4 w-full">
        {initialFavorites.map((item) => {
          const isFries = item.id === 'batata_frita';
          const isEggOpen = activeEasterEgg === item.id;
          const slot = getSlotForFavorite(item.photoSlotId);
          const currentImg = slot?.userImage || item.image;

          return (
            <div
              key={item.id}
              className="group flex flex-col justify-between bg-white rounded-2xl sm:rounded-3xl border border-purple-200 shadow-md shadow-purple-50 hover:shadow-xl hover:shadow-purple-100 transition-all duration-300 overflow-hidden hover:-translate-y-1"
            >
              <div>
                {/* Image Cover */}
                <div className="relative aspect-[4/3] sm:aspect-[16/10] w-full overflow-hidden bg-purple-100">
                  <img
                    src={currentImg}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />

                  {/* Category Pill */}
                  <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/95 backdrop-blur-md border border-purple-200 text-[9px] sm:text-[10px] font-bold text-purple-900 shadow-sm max-w-[70%] truncate">
                    {getCategoryIcon(item.id)}
                    <span className="truncate">{item.category}</span>
                  </div>

                  {item.badge && (
                    <div className="absolute top-2 right-2 px-1.5 sm:px-2 py-0.5 rounded-full bg-purple-600 text-white text-[8px] sm:text-[9px] font-bold uppercase shadow-sm">
                      {item.badge}
                    </div>
                  )}

                  {/* Quick Change button if slot exists */}
                  {slot && (
                    <button
                      onClick={() => onOpenLightbox(slot)}
                      className="absolute bottom-2 right-2 p-1 sm:p-1.5 rounded-lg bg-white/90 hover:bg-purple-600 hover:text-white text-purple-900 border border-purple-200 text-xs shadow-sm transition-all"
                      title="Ver imagem ampliada"
                    >
                      <Sparkles className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                    </button>
                  )}
                </div>

                {/* Content */}
                <div className="p-3 sm:p-4 text-left">
                  <h3 className="text-xs sm:text-base font-bold text-purple-950 mb-1 font-display line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="text-[10px] sm:text-xs text-purple-800/80 leading-relaxed font-light line-clamp-3">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Interactive buttons */}
              <div className="p-3 sm:p-4 pt-0">
                {isFries ? (
                  <div className="space-y-1.5">
                    <button
                      onClick={() => handleEasterEgg(item)}
                      className="w-full py-1.5 sm:py-2 px-2 sm:px-3 rounded-lg sm:rounded-xl text-[10px] sm:text-xs font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 transition-all flex items-center justify-center gap-1 active:scale-95 shadow-xs"
                    >
                      <Utensils className="w-3 h-3 shrink-0" />
                      <span className="truncate">Pegar batatinha</span>
                      {friesCount > 0 && (
                        <span className="ml-0.5 px-1.5 py-0.2 rounded-full bg-amber-500 text-white text-[9px] font-bold">
                          x{friesCount}
                        </span>
                      )}
                    </button>
                  </div>
                ) : (
                  item.easterEggPrompt && (
                    <button
                      onClick={() => handleEasterEgg(item)}
                      className="w-full py-1.5 sm:py-2 px-2 sm:px-3 rounded-lg sm:rounded-xl text-[10px] sm:text-xs font-bold bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 transition-all flex items-center justify-center gap-1 active:scale-95 shadow-xs"
                    >
                      <span className="truncate">{item.easterEggPrompt}</span>
                    </button>
                  )
                )}

                {/* Opened Easter Egg Info */}
                {isEggOpen && (
                  <div className="mt-2 p-2.5 rounded-xl bg-purple-100/80 border border-purple-200 text-[10px] sm:text-xs text-purple-950 text-left animate-fade-in">
                    <p className="font-medium leading-relaxed">{item.easterEggContent}</p>
                    {isFries && friesCount >= 3 && (
                      <p className="mt-1.5 text-[9px] sm:text-[10px] font-bold text-amber-800">
                        *Já pegou {friesCount}! Prometo te pagar uma porção gigante amanhã. 🍟❤️
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
