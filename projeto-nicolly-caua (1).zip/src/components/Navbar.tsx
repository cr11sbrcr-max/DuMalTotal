import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Camera, Heart, Music, Disc3 } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface NavbarProps {
  onOpenPhotoManager: () => void;
  onOpenMusicModal: () => void;
  scrollProgress: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenPhotoManager,
  onOpenMusicModal,
  scrollProgress,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [trackName, setTrackName] = useState('Trilha Lo-Fi');

  useEffect(() => {
    const unsubState = soundFx.subscribeState((playing) => setIsPlaying(playing));
    const unsubTrack = soundFx.subscribeTrack((name) => setTrackName(name));
    return () => {
      unsubState();
      unsubTrack();
    };
  }, []);

  const toggleSound = (e: React.MouseEvent) => {
    e.stopPropagation();
    soundFx.toggleMusic();
  };

  return (
    <header className="sticky top-0 left-0 right-0 z-40 bg-[#faf5ff]/95 backdrop-blur-md border-b border-purple-100 shadow-xs">
      {/* Progress Bar */}
      <div className="h-1 bg-purple-100 w-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-400 transition-all duration-150 ease-out shadow-sm"
          style={{ width: `${Math.min(100, Math.max(0, scrollProgress * 100))}%` }}
        />
      </div>

      {/* Header Bar */}
      <div className="px-3 sm:px-4 py-2 sm:py-2.5 flex items-center justify-between gap-2 max-w-full">
        {/* Left Branding */}
        <div className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1 rounded-full bg-white/90 border border-purple-200 text-xs text-purple-900 shadow-xs shrink-0">
          <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-500 animate-pulse" />
          <span className="font-bold tracking-tight text-xs">Nicolly</span>
          <span className="text-purple-300 font-light">·</span>
          <span className="text-purple-600 font-mono text-[10px] sm:text-[11px] font-semibold">19.08.2024</span>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Photo Manager Toggle for Cauã */}
          <button
            onClick={onOpenPhotoManager}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-full bg-purple-700 hover:bg-purple-800 text-white border border-purple-400/40 text-[11px] sm:text-xs font-semibold transition-all shadow-xs active:scale-95 cursor-pointer"
            title="Gerenciar e colocar nossas fotos"
          >
            <Camera className="w-3.5 h-3.5 shrink-0" />
            <span className="inline">Fotos</span>
          </button>

          {/* Music Manager Pill */}
          <div
            onClick={onOpenMusicModal}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-full border text-[11px] font-medium transition-all shadow-xs cursor-pointer active:scale-95 ${
              isPlaying
                ? 'bg-pink-100/90 border-pink-300 text-pink-900 shadow-pink-100'
                : 'bg-white border-purple-200 text-purple-800 hover:bg-purple-50'
            }`}
            title="Escolher música de fundo ou pausar"
          >
            <button
              onClick={toggleSound}
              className="p-0.5 rounded-full hover:bg-black/5 transition-colors cursor-pointer"
              title={isPlaying ? 'Pausar música' : 'Tocar música'}
            >
              {isPlaying ? (
                <Volume2 className="w-3.5 h-3.5 text-pink-600 animate-pulse shrink-0" />
              ) : (
                <VolumeX className="w-3.5 h-3.5 text-purple-500 shrink-0" />
              )}
            </button>

            <span className="font-bold text-[10px] uppercase tracking-wider text-purple-700">
              {isPlaying ? 'Música' : 'Som'}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
