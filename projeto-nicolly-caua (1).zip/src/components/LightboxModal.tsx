import React from 'react';
import { X, Calendar, Heart } from 'lucide-react';
import { PhotoSlotData } from '../types';

interface LightboxModalProps {
  photo: PhotoSlotData | null;
  onClose: () => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({ photo, onClose }) => {
  if (!photo) return null;

  const activeImage = photo.userImage || photo.defaultImage;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/70 backdrop-blur-md animate-fade-in cursor-zoom-out"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-w-2xl w-full bg-white rounded-3xl border border-purple-200 shadow-2xl overflow-hidden cursor-default"
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 p-2 rounded-full bg-white/90 hover:bg-purple-600 hover:text-white text-purple-900 border border-purple-200 shadow-md transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="relative aspect-[4/5] sm:aspect-[4/3] w-full bg-purple-50 overflow-hidden flex items-center justify-center">
          <img
            src={activeImage}
            alt={photo.title}
            className="w-full h-full object-contain"
          />
        </div>

        <div className="p-6 text-left bg-gradient-to-t from-purple-50 via-white to-white">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <h3 className="text-xl font-bold text-purple-950 font-display">{photo.title}</h3>
            {photo.date && (
              <span className="flex items-center gap-1 text-xs font-mono text-purple-700 font-semibold">
                <Calendar className="w-3.5 h-3.5 text-pink-500" />
                {photo.date}
              </span>
            )}
          </div>

          <p className="font-handwriting text-2xl text-purple-900 leading-relaxed mt-2 font-bold">
            "{photo.caption}"
          </p>
        </div>
      </div>
    </div>
  );
};
