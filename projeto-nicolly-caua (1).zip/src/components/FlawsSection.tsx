import React, { useState } from 'react';
import { ShieldAlert, Heart, ChevronDown, AlertTriangle, Sparkles } from 'lucide-react';
import { cauaFlaws } from '../data/initialData';
import { soundFx } from '../utils/audio';

export const FlawsSection: React.FC = () => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  const toggleExpand = (idx: number) => {
    soundFx.playPop();
    setExpandedIndex(expandedIndex === idx ? null : idx);
  };

  return (
    <section id="defeitos" className="relative py-12 sm:py-16 px-1 sm:px-2 w-full">
      {/* Section Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-100 border border-purple-200 text-xs text-purple-700 font-semibold mb-2.5">
          <ShieldAlert className="w-3.5 h-3.5 text-purple-600" />
          <span>CAPÍTULO 02 · AUTOCRÍTICA SINCERA</span>
        </div>
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-purple-950 tracking-tight font-display">
          Os Defeitos do Cauã
        </h2>
        <p className="mt-2 text-purple-800/80 text-xs sm:text-sm font-light">
          Sem desculpinha e sem fingir que eu era um príncipe de conto de fadas. Reconhecer onde
          eu errava é o mínimo que você merece.
        </p>
      </div>

      {/* The Checklist Cards in Pastel Theme */}
      <div className="space-y-3 w-full mb-10">
        {cauaFlaws.map((item, idx) => {
          const isExpanded = expandedIndex === idx;
          const isLast = idx === cauaFlaws.length - 1;

          return (
            <div
              key={item.flaw}
              onClick={() => toggleExpand(idx)}
              className={`cursor-pointer rounded-2xl border transition-all duration-300 overflow-hidden ${
                isLast
                  ? 'bg-gradient-to-r from-pink-50 via-purple-50 to-pink-50 border-pink-300 shadow-md shadow-pink-100'
                  : isExpanded
                  ? 'bg-white border-purple-400 shadow-md shadow-purple-100'
                  : 'bg-white/90 border-purple-200 hover:border-purple-300 shadow-sm'
              }`}
            >
              <div className="p-4 sm:p-5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {isLast ? (
                    <Heart className="w-5 h-5 text-pink-500 fill-pink-500 animate-pulse shrink-0" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
                  )}
                  <div>
                    <h3
                      className={`text-base sm:text-lg font-bold tracking-tight ${
                        isLast ? 'text-pink-700 font-display' : 'text-purple-950 font-display'
                      }`}
                    >
                      {item.question}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`font-black text-sm sm:text-base px-3.5 py-1 rounded-full border ${
                      isLast
                        ? 'bg-pink-600 text-white border-pink-400 shadow-sm animate-bounce'
                        : 'bg-purple-100 text-purple-800 border-purple-200'
                    }`}
                  >
                    {item.cauãAnswer}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-purple-500 transition-transform duration-300 ${
                      isExpanded ? 'rotate-180' : ''
                    }`}
                  />
                </div>
              </div>

              {/* Collapsible Details */}
              {isExpanded && (
                <div className="px-5 pb-5 pt-1 border-t border-purple-100 text-left bg-purple-50/50">
                  <p className="text-sm text-purple-900 leading-relaxed font-light">
                    {item.explanation}
                  </p>
                  <div className="mt-3 flex items-center justify-between text-xs text-purple-700 font-semibold">
                    <span className="font-mono">Diagnóstico de Cauã:</span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        item.status === 'permanente'
                          ? 'bg-pink-200 text-pink-800'
                          : item.status === 'curado'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {item.status === 'permanente'
                        ? '❤️ Sentimento Vitalício'
                        : item.status === 'curado'
                        ? '✓ Amadurecido'
                        : '⚡ Sob Vigilância Severa'}
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Sincere Reflection */}
      <div className="max-w-2xl mx-auto p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-purple-100/90 via-white to-pink-100/80 border border-purple-200 shadow-lg shadow-purple-100/60 text-left">
        <div className="flex items-start gap-3 mb-3">
          <Sparkles className="w-5 h-5 text-purple-600 shrink-0 mt-0.5" />
          <h4 className="text-lg font-bold text-purple-950 font-display">Do humor pra realidade:</h4>
        </div>
        <p className="text-sm sm:text-base text-purple-900 leading-relaxed font-light">
          Fazer piada com defeito é fácil, mas a verdade é que dói saber que minhas bobeiras e
          paranoias machucaram quem eu mais amava. Eu não quero voltar pra ser aquele mesmo moleque.
          Perder você foi a lição mais dura que já tive, e a única coisa que me fez mudar de verdade.
        </p>
      </div>
    </section>
  );
};
