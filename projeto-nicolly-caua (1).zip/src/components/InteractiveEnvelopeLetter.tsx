import React, { useState } from 'react';
import { Mail, MailOpen, Sparkles, HeartHandshake, Eye, ShieldCheck, Heart } from 'lucide-react';
import { soundFx } from '../utils/audio';

export const InteractiveEnvelopeLetter: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleLetter = () => {
    soundFx.playPop();
    setIsOpen(!isOpen);
  };

  return (
    <section id="amadurecimento" className="relative py-12 sm:py-16 px-1 sm:px-2 w-full">
      {/* Section Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-100 border border-purple-200 text-xs text-purple-700 font-semibold mb-2.5">
          <HeartHandshake className="w-3.5 h-3.5 text-purple-600" />
          <span>CAPÍTULO 06 · PAPO RETO E MATURIDADE</span>
        </div>
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-purple-950 tracking-tight font-display">
          O Que Mudou em Mim
        </h2>
        <p className="mt-2 text-purple-700/80 text-xs sm:text-sm font-light">
          Promessa vazia não adianta de nada. Aqui é a minha verdade, sem filtro, sem orgulho bobo
          e com o coração aberto.
        </p>
      </div>

      {/* Interactive Envelope Trigger */}
      <div className="w-full">
        <div
          onClick={toggleLetter}
          className={`cursor-pointer group p-5 sm:p-7 rounded-3xl transition-all duration-500 border text-center shadow-lg ${
            isOpen
              ? 'bg-gradient-to-b from-purple-50 via-white to-pink-50 border-purple-300 shadow-purple-200/60'
              : 'bg-white hover:bg-purple-50/50 border-purple-200 hover:border-purple-300 shadow-purple-100/70 hover:scale-[1.01]'
          }`}
        >
          {/* Wax Seal Header */}
          <div className="flex flex-col items-center justify-center gap-3 mb-6">
            <div
              className={`p-4 rounded-full transition-all duration-300 shadow-md ${
                isOpen
                  ? 'bg-purple-600 text-white rotate-12 scale-110'
                  : 'bg-pink-100 text-pink-600 group-hover:scale-105'
              }`}
            >
              {isOpen ? <MailOpen className="w-8 h-8" /> : <Mail className="w-8 h-8" />}
            </div>
            <span className="text-xs font-mono font-bold tracking-wider text-purple-700 uppercase">
              {isOpen ? 'Carta Aberta · Toque para fechar' : 'Toque no envelope para ler a carta'}
            </span>
          </div>

          {/* Letter Content (Unfolded) */}
          {isOpen ? (
            <div className="space-y-6 text-left text-base sm:text-lg text-slate-800 leading-relaxed font-light animate-fade-in pt-2">
              <p className="font-bold text-purple-900 text-xl font-display">
                Nicolly,
              </p>

              <p>
                Eu não quero fingir que nada aconteceu. Não quero apagar o que deu errado, nem passar
                pano pros momentos em que eu fui chato, paranoico ou desligado.
              </p>

              <p>
                Não quero voltar no tempo e fingir que eu era perfeito, porque eu definitivamente{' '}
                <span className="font-semibold text-purple-700">não era kkkkkkkkk</span>.
              </p>

              <div className="p-5 rounded-2xl bg-purple-100/70 border-l-4 border-purple-500 my-6">
                <p className="font-handwriting text-2xl text-purple-950 font-bold leading-snug">
                  “Queria que a gente se reconhecesse: a nova Nicolly e o novo Cauã, respeitando
                  um ao outro apesar do que ambos não coincidirem.”
                </p>
              </div>

              <p>
                O tempo longe me fez entender uma lição crucial: <strong className="text-purple-800 font-bold">amar alguém não é sobre sentir muito</strong>.
                Sentir muito é fácil. O que importa de verdade é saber demonstrar, cuidar nos detalhes,
                ouvir com paciência, compreender e estar presente de verdade.
              </p>

              <p>
                Eu amadureci. E se hoje estou aqui colocando a cara a tapa, é porque o que sinto por
                você é grande demais pra caber no orgulho.
              </p>

              {/* 3 Pillars */}
              <div className="pt-6 border-t border-purple-200 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-white border border-purple-200">
                  <Eye className="w-4 h-4 text-purple-600 mb-1" />
                  <h4 className="text-xs font-bold text-purple-900">Presença</h4>
                  <p className="text-[11px] text-purple-700/80">Ouvir você de verdade sem viajar na lua.</p>
                </div>

                <div className="p-3.5 rounded-xl bg-white border border-purple-200">
                  <HeartHandshake className="w-4 h-4 text-pink-500 mb-1" />
                  <h4 className="text-xs font-bold text-purple-900">Diálogo</h4>
                  <p className="text-[11px] text-purple-700/80">Sem bicos bobos, resolvendo na paz.</p>
                </div>

                <div className="p-3.5 rounded-xl bg-white border border-purple-200">
                  <ShieldCheck className="w-4 h-4 text-indigo-600 mb-1" />
                  <h4 className="text-xs font-bold text-purple-900">Cuidado</h4>
                  <p className="text-[11px] text-purple-700/80">Aquele carinho leve e seguro de sempre.</p>
                </div>
              </div>
            </div>
          ) : (
            <p className="font-handwriting text-2xl text-purple-800/80">
              “Amar alguém não é sobre sentir muito. É saber demonstrar, cuidar, ouvir e estar presente...”
            </p>
          )}
        </div>
      </div>
    </section>
  );
};
