import React, { useState, useEffect, useRef } from 'react';
import { X, Music, Upload, Link as LinkIcon, Volume2, VolumeX, Play, Pause, Sparkles, RotateCcw, Check, Disc3 } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface MusicModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MusicModal: React.FC<MusicModalProps> = ({ isOpen, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [trackName, setTrackName] = useState('Trilha Lo-Fi Romântica');
  const [sourceType, setSourceType] = useState<'pixote' | 'custom' | 'lofi'>('pixote');
  const [volume, setVolume] = useState(60);
  const [audioUrlInput, setAudioUrlInput] = useState('');
  const [audioNameInput, setAudioNameInput] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [successFeedback, setSuccessFeedback] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const unsubState = soundFx.subscribeState((playing) => setIsPlaying(playing));
    const unsubTrack = soundFx.subscribeTrack((name, type) => {
      setTrackName(name);
      setSourceType(type);
    });

    setVolume(Math.round(soundFx.getVolume() * 100));

    return () => {
      unsubState();
      unsubTrack();
    };
  }, []);

  if (!isOpen) return null;

  const showNotification = (msg: string) => {
    setSuccessFeedback(msg);
    setTimeout(() => setSuccessFeedback(null), 3000);
  };

  const handleTogglePlay = () => {
    soundFx.toggleMusic();
  };

  const handleSelectOfficialPixote = async () => {
    await soundFx.resetToPixote();
    soundFx.playCelebration();
    showNotification('Música "Pixote - Mande Um Sinal" definida como a oficial!');
    if (!soundFx.getIsPlaying()) {
      soundFx.toggleMusic();
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setVolume(val);
    soundFx.setVolume(val / 100);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      const cleanName = file.name.replace(/\.[^/.]+$/, '');
      await soundFx.setCustomAudioFile(file, cleanName);
      soundFx.playCelebration();
      showNotification(`Música "${cleanName}" carregada com sucesso!`);
      // Start playing custom track immediately
      if (!soundFx.getIsPlaying()) {
        soundFx.toggleMusic();
      }
    } catch (err) {
      console.error('Erro ao carregar áudio:', err);
      showNotification('Erro ao carregar o arquivo de áudio.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleApplyUrl = () => {
    if (!audioUrlInput.trim()) return;
    const name = audioNameInput.trim() || 'Música do Casal';
    soundFx.setCustomAudioUrl(audioUrlInput.trim(), name);
    soundFx.playCelebration();
    showNotification(`Música "${name}" adicionada por link!`);
    if (!soundFx.getIsPlaying()) {
      soundFx.toggleMusic();
    }
    setAudioUrlInput('');
    setAudioNameInput('');
  };

  const handleResetToLofi = async () => {
    await soundFx.resetToLofi();
    soundFx.playPop();
    showNotification('Restaurado para a Trilha Lo-Fi Romântica.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-purple-950/60 backdrop-blur-md animate-fade-in">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept="audio/*"
        className="hidden"
      />

      <div className="relative w-full max-w-lg rounded-t-[32px] sm:rounded-3xl bg-white border border-purple-200 shadow-2xl text-slate-800 overflow-hidden max-h-[92vh] flex flex-col">
        {/* Mobile Pull Handle */}
        <div className="w-12 h-1.5 bg-purple-200 rounded-full mx-auto my-2 sm:hidden shrink-0" />

        {/* Header */}
        <div className="px-5 sm:px-6 py-4 sm:py-5 border-b border-purple-100 flex items-center justify-between bg-gradient-to-r from-purple-50 via-white to-pink-50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-purple-100 text-purple-700">
              <Music className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-purple-950 font-display">
                Música de Fundo
              </h3>
              <p className="text-xs text-purple-700/80">
                Escolha qualquer música que você quiser para tocar
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-purple-100 text-purple-500 hover:text-purple-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Notification Feedback Toast */}
          {successFeedback && (
            <div className="p-3 rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-semibold flex items-center gap-2 animate-fade-in">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successFeedback}</span>
            </div>
          )}

          {/* Current Playing Card */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-purple-100 via-pink-50 to-white border border-purple-200 shadow-sm flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
                    isPlaying
                      ? 'bg-purple-600 text-white shadow-md shadow-purple-300 animate-spin-slow'
                      : 'bg-purple-100 text-purple-600'
                  }`}
                  style={{ animationDuration: '6s' }}
                >
                  <Disc3 className="w-6 h-6" />
                </div>
                <div className="min-w-0">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-purple-600 font-bold block">
                    {sourceType === 'custom' ? 'Sua Música Personalizada' : 'Trilha Ambiente'}
                  </span>
                  <h4 className="font-bold text-sm sm:text-base text-purple-950 truncate max-w-[200px] sm:max-w-[240px]">
                    {trackName}
                  </h4>
                </div>
              </div>

              {/* Animated Equalizer Bars */}
              <div className="flex items-end gap-1 h-6">
                {[40, 90, 60, 100, 75].map((height, i) => (
                  <span
                    key={i}
                    className={`w-1 bg-purple-500 rounded-full transition-all duration-300 ${
                      isPlaying ? 'animate-pulse' : 'opacity-30'
                    }`}
                    style={{
                      height: isPlaying ? `${height}%` : '20%',
                      animationDelay: `${i * 150}ms`,
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Play/Pause Button and Volume Control */}
            <div className="pt-2 border-t border-purple-200/70 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button
                onClick={handleTogglePlay}
                className={`w-full sm:w-auto px-5 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 cursor-pointer ${
                  isPlaying
                    ? 'bg-pink-600 hover:bg-pink-700 text-white shadow-pink-200'
                    : 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-200'
                }`}
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4" />
                    <span>Pausar Música</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    <span>Tocar Agora</span>
                  </>
                )}
              </button>

              <div className="w-full sm:w-auto flex items-center gap-2">
                <button
                  onClick={() => {
                    const newVol = volume > 0 ? 0 : 50;
                    setVolume(newVol);
                    soundFx.setVolume(newVol / 100);
                  }}
                  className="p-1.5 rounded-lg hover:bg-purple-100 text-purple-700 transition-colors"
                  title="Mudo"
                >
                  {volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={handleVolumeChange}
                  className="w-24 sm:w-28 h-2 bg-purple-200 rounded-lg appearance-none cursor-pointer accent-purple-600"
                />
                <span className="text-[11px] font-mono text-purple-700 w-8 text-right font-semibold">
                  {volume}%
                </span>
              </div>
            </div>
          </div>

          {/* Featured Official Track: Pixote - Mande Um Sinal */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-pink-500/10 via-purple-500/10 to-indigo-500/10 border-2 border-purple-300 shadow-md relative overflow-hidden">
            <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-pink-600 text-white text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 shadow-sm">
              <Sparkles className="w-3 h-3" />
              <span>Música Oficial do Site</span>
            </div>

            <div className="space-y-2.5">
              <span className="text-[11px] font-bold text-purple-700 uppercase tracking-wider">
                Trilha Original Fixada
              </span>
              <h4 className="font-extrabold text-base text-purple-950 font-display">
                Pixote - Mande Um Sinal (15 Anos - Ao Vivo)
              </h4>
              <p className="text-xs text-purple-900/80 leading-relaxed font-light">
                A música que você escolheu para o site da Nicolly. Já está gravada como padrão oficial
                para tocar com emoção quando ela abrir o site no celular!
              </p>

              <div className="pt-2 flex items-center gap-2">
                <button
                  onClick={handleSelectOfficialPixote}
                  className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-sm ${
                    sourceType === 'pixote'
                      ? 'bg-purple-700 text-white'
                      : 'bg-purple-100 hover:bg-purple-200 text-purple-900'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-pink-300" />
                  <span>{sourceType === 'pixote' ? '✓ Definida como Ativa' : 'Tocar Pixote Oficial'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Option 1: Upload from Device */}
          <div className="p-5 rounded-3xl bg-white border border-purple-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <Upload className="w-4 h-4 text-purple-600" />
              <h4 className="font-bold text-sm text-purple-950">
                1. Escolher Música do seu Celular ou Computador
              </h4>
            </div>
            <p className="text-xs text-purple-800/80 leading-relaxed font-light">
              Selecione qualquer arquivo de áudio (MP3, M4A, WAV, etc.) que marcou a história de vocês.
              A música fica salva automaticamente para tocar sempre que o site for aberto.
            </p>

            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="w-full py-3 px-4 rounded-2xl bg-purple-100 hover:bg-purple-200 text-purple-900 border border-purple-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <Upload className="w-4 h-4 text-purple-700" />
              <span>{isUploading ? 'Carregando Música...' : 'Selecionar Arquivo de Música'}</span>
            </button>
          </div>

          {/* Option 2: Direct Audio Link */}
          <div className="p-5 rounded-3xl bg-white border border-purple-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <LinkIcon className="w-4 h-4 text-purple-600" />
              <h4 className="font-bold text-sm text-purple-950">
                2. Ou Inserir Link Direto de Áudio (URL)
              </h4>
            </div>
            <p className="text-xs text-purple-800/80 leading-relaxed font-light">
              Tem um link direto (.mp3, streaming ou áudio hospedado)? Cole abaixo:
            </p>

            <div className="space-y-2">
              <input
                type="text"
                placeholder="Nome da música (ex: Nossa Música Especial)"
                value={audioNameInput}
                onChange={(e) => setAudioNameInput(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl bg-purple-50/50 border border-purple-200 text-purple-950 placeholder-purple-400 focus:outline-none focus:border-purple-500"
              />
              <input
                type="url"
                placeholder="https://exemplo.com/musica.mp3"
                value={audioUrlInput}
                onChange={(e) => setAudioUrlInput(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl bg-purple-50/50 border border-purple-200 text-purple-950 placeholder-purple-400 focus:outline-none focus:border-purple-500"
              />
              <button
                onClick={handleApplyUrl}
                disabled={!audioUrlInput.trim()}
                className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Aplicar Link de Música</span>
              </button>
            </div>
          </div>

          {/* Option 3: Reset to Procedural Lo-Fi */}
          {sourceType === 'custom' && (
            <div className="text-center pt-2">
              <button
                onClick={handleResetToLofi}
                className="inline-flex items-center gap-1.5 text-xs text-purple-700 hover:text-purple-950 font-semibold underline transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Voltar para a Trilha Lo-Fi Romântica Padrão</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-purple-100 flex items-center justify-end bg-purple-50/50">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer"
          >
            Concluir
          </button>
        </div>
      </div>
    </div>
  );
};
