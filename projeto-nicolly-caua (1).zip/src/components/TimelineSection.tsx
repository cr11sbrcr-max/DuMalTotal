import React from 'react';
import { Calendar, Clock, Heart, Compass, Sparkles, Flame } from 'lucide-react';
import { PhotoSlotData } from '../types';
import { PhotoCard } from './PhotoCard';

interface TimelineSectionProps {
  photoSlots: PhotoSlotData[];
  onUploadFile: (id: string, file: File) => void;
  onOpenLightbox: (photo: PhotoSlotData) => void;
}

export const TimelineSection: React.FC<TimelineSectionProps> = ({
  photoSlots,
  onUploadFile,
  onOpenLightbox,
}) => {
  const origemPhoto = photoSlots.find((p) => p.section === 'origem');
  const startPhotos = photoSlots.filter((p) => p.section === 'comeco');

  return (
    <section id="historia" className="relative py-12 sm:py-16 px-1 sm:px-2 w-full">
      {/* Special Prologue: 2022 (Caso Antigo rs) */}
      {origemPhoto && (
        <div className="mb-14 w-full">
          <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-purple-100 via-pink-50 to-white border border-purple-200 shadow-lg shadow-purple-100/70 text-left relative overflow-hidden">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-700 text-white text-[10px] sm:text-[11px] font-bold uppercase tracking-wider mb-3 shadow-xs">
              <Flame className="w-3 h-3 text-pink-300 shrink-0" />
              <span className="truncate">O Segredo de 2022 · Caso antigo né rs (só pra mim kkkkkkkkkkkk ai)</span>
            </div>

            <div className="flex flex-col gap-4">
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-purple-950 font-display">
                  Tudo começou nessa noite em 2022...
                </h3>
                <p className="mt-2 text-xs sm:text-sm text-purple-800 leading-relaxed font-light">
                  Muito antes de 19/08/2024, teve aquela noite inesquecível de 2022 onde no meu coração
                  eu já tinha selado quem seria a mulher da minha vida. Caso antigo né rs... só pra mim kkkkkkkkkkkk ai.
                </p>
                <p className="mt-2.5 font-handwriting text-xl sm:text-2xl text-purple-900 font-bold">
                  “Desde aquela noite, eu já sabia que era você.”
                </p>
              </div>

              <div className="w-full max-w-[240px] mx-auto pt-2">
                <PhotoCard
                  photo={origemPhoto}
                  onUploadFile={onUploadFile}
                  onOpenLightbox={onOpenLightbox}
                  rotate="rotate-1"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Section Header: 19.08.2024 */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-100 border border-purple-200 text-xs text-purple-700 font-semibold mb-2.5">
          <Calendar className="w-3.5 h-3.5 text-purple-600" />
          <span>CAPÍTULO 01 · NOSSA HISTÓRIA</span>
        </div>
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-purple-950 tracking-tight font-display">
          O Começo de Tudo
        </h2>
        <div className="mt-1.5 flex items-center justify-center gap-1.5 text-purple-700 font-bold text-base sm:text-lg">
          <Clock className="w-4 h-4 text-pink-500" />
          <span>19 de Agosto de 2024</span>
        </div>
        <p className="mt-2.5 text-purple-800/80 text-xs sm:text-sm leading-relaxed font-light">
          O início de um namoro que sempre foi marcado por leveza, pureza e uma paz que era só nossa.
          A gente nunca precisou forçar nada pra ser feliz.
        </p>
      </div>

      {/* The 2 Initial Photos Grid (Cinema no Jardim & Show de Óculos) - Fileira de Dois */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-4 mb-12 w-full">
        {startPhotos.map((photo, index) => (
          <div key={photo.id} className="relative w-full">
            <PhotoCard
              photo={photo}
              onUploadFile={onUploadFile}
              onOpenLightbox={onOpenLightbox}
              rotate={index === 0 ? '-rotate-1' : 'rotate-1'}
            />
          </div>
        ))}
      </div>

      {/* Journey Timeline Cards */}
      <div className="relative border-l-2 border-purple-300 pl-5 ml-3 space-y-6">
        {/* Step 1 */}
        <div className="relative">
          <div className="absolute -left-[27px] top-1 w-5 h-5 rounded-full bg-white border-2 border-purple-600 flex items-center justify-center text-purple-700 font-bold text-[10px] shadow-xs">
            1
          </div>
          <div className="bg-white p-4 rounded-2xl border border-purple-200 shadow-xs">
            <span className="text-[10px] font-mono text-purple-600 font-bold uppercase tracking-wider block">
              19 de Agosto de 2024 · O Start
            </span>
            <h3 className="text-base font-bold text-purple-950 mt-0.5">O Primeiro Cinema &amp; O Jardim</h3>
            <p className="mt-1.5 text-xs text-purple-800/80 leading-relaxed font-light">
              Fomos ao cinema juntos pela primeira vez... depois fomos pro jardim, tiramos nossa foto
              com filtro de cachorrinho e aquele momento foi o desencadeamento oficial do nosso namoro.
            </p>
          </div>
        </div>

        {/* Step 2 */}
        <div className="relative">
          <div className="absolute -left-[27px] top-1 w-5 h-5 rounded-full bg-white border-2 border-fuchsia-500 flex items-center justify-center text-fuchsia-600 font-bold text-[10px] shadow-xs">
            2
          </div>
          <div className="bg-white p-4 rounded-2xl border border-purple-200 shadow-xs">
            <span className="text-[10px] font-mono text-fuchsia-600 font-bold uppercase tracking-wider block">
              Aquele Show · Sensação Inexplicável
            </span>
            <h3 className="text-base font-bold text-purple-950 mt-0.5">O Alívio de Te Encontrar</h3>
            <p className="mt-1.5 text-xs text-purple-800/80 leading-relaxed font-light">
              Eu lembro que eu tava tristão no meio da multidão achando que não ia te achar no show...
              mas quando bati o olho e te encontrei, veio aquele alívio e uma sensação boa inexplicável.
            </p>
          </div>
        </div>
      </div>

      {/* Sincere takeaway */}
      <div className="mt-10 p-5 rounded-3xl bg-gradient-to-r from-purple-100 via-pink-50 to-indigo-100 border border-purple-200 text-center shadow-xs">
        <Compass className="w-5 h-5 text-purple-600 mx-auto mb-1.5" />
        <p className="font-handwriting text-xl sm:text-2xl text-purple-950">
          "A nossa história pausou, mas o carinho e o sentimento continuam vivos dentro de mim."
        </p>
      </div>
    </section>
  );
};
