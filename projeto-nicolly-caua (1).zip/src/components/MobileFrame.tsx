import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Wifi, BatteryMedium, Heart, Disc3 } from 'lucide-react';
import { soundFx } from '../utils/audio';
import { FallingHeartsBackground } from './FallingHeartsBackground';

interface MobileFrameProps {
  children: React.ReactNode;
  scrollProgress: number;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({ children, scrollProgress }) => {
  const [isFramed, setIsFramed] = useState<boolean>(() => {
    // Default to true on desktop since user explicitly requested mobile framing
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('nicolly_mobile_frame_mode');
      if (saved !== null) return saved === 'true';
      return window.innerWidth >= 640;
    }
    return true;
  });

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState('19:08');

  useEffect(() => {
    const unsub = soundFx.subscribeState((playing) => setIsPlaying(playing));
    return () => unsub();
  }, []);

  const handleToggleFrame = (mode: boolean) => {
    soundFx.playPop();
    setIsFramed(mode);
    localStorage.setItem('nicolly_mobile_frame_mode', String(mode));
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-start relative py-0 sm:py-6 lg:py-8 px-0 sm:px-4">
      {/* Top Floating Viewport Switcher for Desktop / Tablet */}
      <div className="hidden sm:flex items-center gap-2 mb-4 z-40 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-purple-200/90 shadow-md text-xs font-medium text-purple-900 animate-fade-in">
        <span className="text-[11px] font-mono text-purple-600 font-bold uppercase tracking-wider flex items-center gap-1 mr-1">
          <Heart className="w-3 h-3 text-pink-500 fill-pink-500" />
          <span>Enquadração:</span>
        </span>

        <button
          onClick={() => handleToggleFrame(true)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
            isFramed
              ? 'bg-purple-700 text-white shadow-xs'
              : 'text-purple-700 hover:bg-purple-100'
          }`}
          title="Ver o site enquadrado como celular"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Celular</span>
        </button>

        <button
          onClick={() => handleToggleFrame(false)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
            !isFramed
              ? 'bg-purple-700 text-white shadow-xs'
              : 'text-purple-700 hover:bg-purple-100'
          }`}
          title="Ver o site em largura ampla"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Expandido</span>
        </button>
      </div>

      {/* Main Container - Framed as Phone or Full Width */}
      <div
        className={`w-full transition-all duration-300 relative ${
          isFramed
            ? 'sm:max-w-[430px] sm:rounded-[50px] sm:border-[10px] sm:border-slate-900 sm:shadow-[0_25px_80px_rgba(147,51,234,0.35),0_15px_35px_rgba(0,0,0,0.3)] sm:ring-1 sm:ring-purple-300/40 bg-[#faf5ff] overflow-hidden'
            : 'max-w-4xl bg-[#faf5ff]'
        }`}
      >
        {/* Hardware Frame Simulator Buttons (Left & Right Edge Silhouettes on Desktop) */}
        {isFramed && (
          <>
            {/* Left volume rocker accents (visible on outer edge) */}
            <div className="hidden sm:block absolute -left-[14px] top-28 w-[4px] h-9 bg-slate-700 rounded-l-xs pointer-events-none" />
            <div className="hidden sm:block absolute -left-[14px] top-42 w-[4px] h-12 bg-slate-700 rounded-l-xs pointer-events-none" />
            <div className="hidden sm:block absolute -left-[14px] top-58 w-[4px] h-12 bg-slate-700 rounded-l-xs pointer-events-none" />
            {/* Right power button accent */}
            <div className="hidden sm:block absolute -right-[14px] top-36 w-[4px] h-16 bg-slate-700 rounded-r-xs pointer-events-none" />
          </>
        )}

        {/* Dynamic Island & Phone Status Bar (Desktop Framed Mode Only) */}
        {isFramed && (
          <div className="hidden sm:flex items-center justify-between px-6 pt-3 pb-2 bg-[#faf5ff] border-b border-purple-100/60 sticky top-0 z-50 select-none">
            {/* Time (19:08 - The Anniversary Day) */}
            <div className="flex items-center gap-1 text-[11px] font-bold text-slate-800 font-mono tracking-tight">
              <span>{currentTime}</span>
              <Heart className="w-2.5 h-2.5 text-pink-500 fill-pink-500 animate-pulse" />
            </div>

            {/* Dynamic Island Pill */}
            <div className="h-6 px-3 bg-black rounded-full flex items-center justify-center gap-2 shadow-inner text-white text-[10px] min-w-[110px]">
              {/* Front Camera Lens Reflection */}
              <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center">
                <div className="w-1 h-1 rounded-full bg-blue-950" />
              </div>

              {/* Music Indicator inside Dynamic Island */}
              {isPlaying ? (
                <div className="flex items-center gap-1.5 text-pink-300 font-mono text-[9px] animate-pulse">
                  <Disc3 className="w-3 h-3 animate-spin text-pink-400" />
                  <span>tocando</span>
                </div>
              ) : (
                <div className="w-2 h-2 rounded-full bg-purple-900 border border-purple-700" />
              )}
            </div>

            {/* Signal & Battery */}
            <div className="flex items-center gap-1.5 text-slate-700 text-xs">
              <span className="text-[10px] font-mono font-bold">5G</span>
              <Wifi className="w-3 h-3" />
              <div className="flex items-center gap-0.5">
                <div className="w-4 h-2.5 border border-slate-700 rounded-xs p-0.5 flex items-center">
                  <div className="w-full h-full bg-purple-700 rounded-xs" />
                </div>
                <div className="w-0.5 h-1 bg-slate-700 rounded-r-xs" />
              </div>
            </div>
          </div>
        )}

        {/* Dedicated Falling Hearts inside phone background */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
          <div className="sticky top-0 h-screen w-full pointer-events-none">
            <FallingHeartsBackground isAbsolute className="opacity-90" />
          </div>
        </div>

        {/* Inside Phone Screen Content */}
        <div className="relative w-full z-10">
          {children}
        </div>

        {/* Home Indicator Bar for iPhone Frame (Desktop Framed Mode Only) */}
        {isFramed && (
          <div className="hidden sm:block w-full py-2 bg-[#faf5ff] pointer-events-none sticky bottom-0 z-30">
            <div className="w-32 h-1 bg-slate-400/60 rounded-full mx-auto" />
          </div>
        )}
      </div>
    </div>
  );
};
