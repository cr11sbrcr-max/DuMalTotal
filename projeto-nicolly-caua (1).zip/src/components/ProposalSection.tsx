import React, { useState } from 'react';
import { Heart, MessageCircle, RefreshCw, Send, Check, Sparkles, UtensilsCrossed } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundFx } from '../utils/audio';

export const ProposalSection: React.FC = () => {
  const [decision, setDecision] = useState<'pending' | 'accepted' | 'dinner' | 'declined'>('pending');
  const [copied, setCopied] = useState(false);
  const [noHoverCount, setNoHoverCount] = useState(0);

  const handleAccept = () => {
    soundFx.playCelebration();
    setDecision('accepted');

    const duration = 4 * 1000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 6,
        angle: 60,
        spread: 60,
        origin: { x: 0 },
        colors: ['#c084fc', '#f472b6', '#a855f7', '#fb7185', '#e879f9'],
      });
      confetti({
        particleCount: 6,
        angle: 120,
        spread: 60,
        origin: { x: 1 },
        colors: ['#c084fc', '#f472b6', '#a855f7', '#fb7185', '#e879f9'],
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();
  };

  const handleDinner = () => {
    soundFx.playCelebration();
    setDecision('dinner');

    const duration = 3.5 * 1000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 70,
        spread: 55,
        origin: { x: 0.1 },
        colors: ['#f59e0b', '#ec4899', '#a855f7', '#10b981'],
      });
      confetti({
        particleCount: 5,
        angle: 110,
        spread: 55,
        origin: { x: 0.9 },
        colors: ['#f59e0b', '#ec4899', '#a855f7', '#10b981'],
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();
  };

  const handleDecline = () => {
    soundFx.playPop();
    setDecision('declined');
  };

  const handleNoHover = () => {
    if (noHoverCount < 2) {
      setNoHoverCount((prev) => prev + 1);
    }
  };

  const zapMessageCaridade = encodeURIComponent(
    'Oi seu feio... eu vi o site todinho kkkkkk. Tá, vou fazer essa caridade, vem me abraçar ❤️'
  );

  const zapMessageJantar = encodeURIComponent(
    'Oi seu feio... aceito o jantar! Vamos conversar olho no olho e nos resolver de verdade 🍽️❤️'
  );

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="o-que-quero" className="relative py-12 sm:py-16 px-1 sm:px-2 w-full text-center">
      {/* 01. O QUE EU QUERO */}
      <div className="mb-12">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-100 border border-purple-200 text-xs text-purple-700 font-semibold mb-2.5">
          <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-500" />
          <span>CAPÍTULO 07 · O QUE EU QUERO</span>
        </div>

        <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-purple-950 tracking-tight font-display mb-4">
          Uma Chance de Construir Algo Novo
        </h2>

        <div className="w-full p-5 sm:p-7 rounded-3xl bg-white border border-purple-200 shadow-lg shadow-purple-100/70 text-left">
          <p className="font-handwriting text-xl sm:text-2xl text-purple-900 font-bold leading-snug mb-3">
            “Eu não estou te pedindo para esquecer o passado.
            Estou te pedindo uma chance de construir algo novo comigo, tentador não rs 😉.”
          </p>

          <p className="text-xs sm:text-sm text-purple-800/90 leading-relaxed font-light">
            Eu não quero simplesmente voltar pro passado e repetir o que desgastou. Quero uma
            oportunidade para construir com você uma relação mais madura, com muito diálogo, mais
            leveza, mais risadas e com a certeza de que a gente se escolhe todo dia.
          </p>
        </div>
      </div>

      {/* 02. O FINAL ÍNTIMO E EMOCIONAL */}
      <div className="relative w-full p-5 sm:p-8 rounded-3xl bg-gradient-to-b from-purple-100/90 via-white to-pink-50 border border-purple-300 shadow-xl overflow-hidden">
        {decision === 'pending' && (
          <div className="relative z-10 text-left space-y-5">
            <div className="text-center mb-6">
              <span className="text-3xl">💌</span>
              <h3 className="text-2xl sm:text-3xl font-black text-purple-950 font-display mt-2">
                Nicolly, minha pitica…
              </h3>
            </div>

            <div className="space-y-4 text-base sm:text-lg text-purple-950 font-light leading-relaxed">
              <p>Eu ainda amo você.</p>
              <p>Ainda penso em você todo santinho dia.</p>
              <p>Ainda lembro de cada detalhe das nossas coisas.</p>
              <p>
                E, apesar de tudo que aconteceu, uma parte de mim ainda acredita que nossa história
                não precisava terminar daquele jeito...{' '}
                <span className="font-mono text-xs text-purple-600 font-normal">
                  ei psiu, não ria de mim kkkkkkkk nem sei lá.
                </span>
              </p>
              <p>Eu não sei se você ainda sente alguma coisa por mim.</p>
              <p className="italic text-purple-700 font-medium">
                E sinceramente… espero que sinta pelo menos um pouquinho KKKKKKK.
              </p>
              <p className="pt-2 font-bold text-purple-950">Mas eu sei o que eu sinto.</p>
              <p>
                Eu queria uma nova chance. Não para repetir o que fomos. Mas para descobrir o que
                a gente ainda pode ser.
              </p>
              <p className="text-2xl sm:text-3xl font-handwriting text-purple-900 font-bold pt-3 text-center">
                Vem na minha, vem bebê?
              </p>
            </div>

            {/* The Three Action Buttons */}
            <div className="pt-8 flex flex-col gap-3.5">
              {/* Option 1: Caridade */}
              <button
                onClick={handleAccept}
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white font-bold text-sm sm:text-base shadow-xl shadow-purple-300/60 border border-white/30 transition-all hover:scale-[1.01] active:scale-[0.98] cursor-pointer"
              >
                ❤️ vou fazer caridade com você menino fei
              </button>

              {/* Option 2: Jantar pra se resolver de verdade */}
              <button
                onClick={handleDinner}
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:from-amber-600 hover:to-purple-700 text-white font-bold text-sm sm:text-base shadow-xl shadow-amber-200/60 border border-white/30 transition-all hover:scale-[1.01] active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
              >
                <UtensilsCrossed className="w-5 h-5 shrink-0" />
                <span>🍽️ te levo pra jantar e de lá a gente se resolve de verdade</span>
              </button>

              {/* Option 3: Recusar com respeito */}
              <button
                onClick={handleDecline}
                onMouseEnter={handleNoHover}
                style={{
                  transform: noHoverCount === 1 ? 'translateX(18px)' : 'none',
                  transition: 'transform 0.2s ease',
                }}
                className="w-full py-3.5 px-5 rounded-2xl bg-white hover:bg-purple-50 text-purple-700 font-semibold text-xs sm:text-sm border border-purple-200 transition-all active:scale-[0.98] cursor-pointer shadow-xs"
              >
                🖤 não, saí fora cachorro do mato
              </button>
            </div>
          </div>
        )}

        {/* DECISION: JANTAR (NOVO!) */}
        {decision === 'dinner' && (
          <div className="relative z-10 text-center py-6 space-y-6 animate-fade-in">
            <div className="inline-flex p-4 rounded-full bg-amber-100 border border-amber-300 text-amber-600 animate-bounce">
              <UtensilsCrossed className="w-10 h-10" />
            </div>

            <h3 className="text-3xl sm:text-4xl font-black text-purple-950 font-display">
              FECHOU O JANTAR! 🍽️✨
            </h3>

            <div className="p-6 rounded-3xl bg-white border border-purple-200 shadow-md text-purple-950 text-base sm:text-lg leading-relaxed font-light text-left space-y-3">
              <p className="font-bold text-purple-900 text-xl font-display">
                Olho no olho, sem pressa e do jeito certo.
              </p>
              <p>
                Um jantar a dois, só nós dois, num lugar tranquilo. A gente senta, conversa com maturidade,
                troca aquele papo bom que sempre tivemos e se resolve de verdade, com calma, carinho e respeito.
              </p>
              <p className="font-handwriting text-2xl text-purple-800 font-bold">
                “Já me manda no zap qual restaurante você quer ir pra gente acertar tudo!”
              </p>
            </div>

            {/* Direct WhatsApp Action Button for Dinner */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <a
                href={`https://wa.me/?text=${zapMessageJantar}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-base shadow-xl shadow-emerald-200 transition-all hover:scale-105 active:scale-95"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Combinar o Jantar no Zap</span>
              </a>

              <button
                onClick={() => handleCopy('Oi seu feio... aceito o jantar! Vamos conversar olho no olho e nos resolver de verdade 🍽️❤️')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-white hover:bg-purple-50 text-purple-800 border border-purple-200 text-sm font-bold transition-all active:scale-95 shadow-sm"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Send className="w-4 h-4" />}
                <span>{copied ? 'Mensagem copiada!' : 'Copiar resposta'}</span>
              </button>
            </div>

            <button
              onClick={() => setDecision('pending')}
              className="inline-flex items-center gap-1.5 text-xs text-purple-600 hover:text-purple-900 font-mono transition-colors pt-4 font-semibold"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Ver as opções de novo</span>
            </button>
          </div>
        )}

        {/* DECISION: ACCEPTED */}
        {decision === 'accepted' && (
          <div className="relative z-10 text-center py-6 space-y-6 animate-fade-in">
            <div className="inline-flex p-4 rounded-full bg-pink-100 border border-pink-300 text-pink-500 animate-bounce">
              <Heart className="w-10 h-10 fill-pink-500" />
            </div>

            <h3 className="text-3xl sm:text-4xl font-black text-purple-950 font-display">
              AIIIIIIIIIIIII KRLH! ❤️
            </h3>

            <div className="p-6 rounded-3xl bg-white border border-purple-200 shadow-md text-purple-950 text-base sm:text-lg leading-relaxed font-light">
              <p className="font-bold text-purple-900 mb-2">
                “AIIIIIIIIIIIII KRLH, vo goza, eu te amo, te amo, te amo, te amo, deixa eu te abraçar
                e nunca mais te soltar, ja vem de zap p gente fazer o dialogo e amanhã eu te vejo
                sem deixar p dps p gente se acertar, bjoooo”
              </p>
            </div>

            {/* Direct WhatsApp Action Button */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <a
                href={`https://wa.me/?text=${zapMessageCaridade}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-base shadow-xl shadow-emerald-200 transition-all hover:scale-105 active:scale-95"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Mandar no Zap do Cauã</span>
              </a>

              <button
                onClick={() => handleCopy('Oi seu feio... eu vi o site todinho kkkkkk. Tá, vou fazer essa caridade, vem me abraçar ❤️')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-white hover:bg-purple-50 text-purple-800 border border-purple-200 text-sm font-bold transition-all active:scale-95 shadow-sm"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Send className="w-4 h-4" />}
                <span>{copied ? 'Mensagem copiada!' : 'Copiar resposta'}</span>
              </button>
            </div>

            <button
              onClick={() => setDecision('pending')}
              className="inline-flex items-center gap-1.5 text-xs text-purple-600 hover:text-purple-900 font-mono transition-colors pt-4 font-semibold"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Ver proposta de novo</span>
            </button>
          </div>
        )}

        {/* DECISION: DECLINED (Pure Respect, Zero Guilt) */}
        {decision === 'declined' && (
          <div className="relative z-10 text-center py-6 space-y-6 animate-fade-in">
            <div className="inline-flex p-4 rounded-full bg-purple-100 border border-purple-200 text-purple-600">
              <Heart className="w-8 h-8 text-pink-500" />
            </div>

            <div className="p-6 rounded-3xl bg-white border border-purple-200 shadow-md text-purple-950 text-base sm:text-lg leading-relaxed">
              <p className="font-bold text-purple-900 text-2xl font-handwriting">
                “Af belezinha, te respeito de montão, valeuzin por ter chegado até aqui. ❤️”
              </p>
              <p className="mt-4 text-sm text-purple-800/80 font-light">
                Sem pressão, sem drama e sem rancor. Meu carinho por você é real e verdadeiro,
                independentemente de qualquer resposta. Obrigado de coração por ter visto até o fim.
              </p>
            </div>

            <button
              onClick={() => setDecision('pending')}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full bg-white border border-purple-300 text-xs text-purple-700 hover:bg-purple-50 font-bold transition-all active:scale-95 shadow-xs"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Voltar e rever</span>
            </button>
          </div>
        )}
      </div>

      {/* Footer Signature */}
      <div className="mt-16 text-center text-xs text-purple-600/70 font-mono">
        <p>Feito pelo Cauã exclusivamente para a Nicolly</p>
        <p className="mt-1 text-[11px]">19.08.2024 · Leveza, respeito e muito amor (não me humilhe pfv)</p>
      </div>
    </section>
  );
};
