import React from 'react';
import { ArrowDown, Sparkles, Heart } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface HeroSectionProps {
  onStartExperience: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onStartExperience }) => {
  const handleStart = () => {
    soundFx.playSparkle();
    onStartExperience();
  };

  return (
    <section className="relative min-h-[84vh] sm:min-h-[88vh] flex flex-col items-center justify-center text-center px-4 pt-12 sm:pt-16 pb-12 sm:pb-16 overflow-hidden">
      {/* Decorative soft blurred circles */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 rounded-full bg-purple-200/50 blur-[90px] pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 rounded-full bg-pink-200/50 blur-[100px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full bg-indigo-200/40 blur-[120px] pointer-events-none" />

      {/* Playful Top Badge */}
      <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/90 border border-purple-200 text-[11px] sm:text-xs text-purple-700 font-semibold mb-5 shadow-xs backdrop-blur-md animate-fade-in max-w-[90%]">
        <Heart className="w-3 h-3 text-pink-500 fill-pink-500 animate-pulse shrink-0" />
        <span className="truncate">100% de coração &amp; 0% de vergonha na cara</span>
        <Sparkles className="w-3 h-3 text-purple-500 shrink-0" />
      </div>

      {/* Main Name Header */}
      <div className="relative mb-5">
        <h1 className="text-5xl sm:text-6xl md:text-7xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-purple-800 via-fuchsia-700 to-pink-600 drop-shadow-sm font-display leading-tight">
          Nicolly
        </h1>
        <span className="block mt-1 font-handwriting text-xl sm:text-2xl text-purple-700 font-bold rotate-[-1deg]">
          minha eterna pitica, momo &amp; cabeçuda ✨
        </span>
      </div>

      {/* Provocative and funny hook */}
      <div className="w-full max-w-xs sm:max-w-sm mx-auto mb-8 px-4 sm:px-5 py-4 rounded-2xl bg-white/95 border border-purple-200 shadow-md shadow-purple-100/60 backdrop-blur-md text-slate-800">
        <p className="text-sm sm:text-base font-medium leading-snug">
          “Antes que você feche esse site… calma.
          <span className="block mt-0.5 font-bold text-purple-700">
            Eu prometo que não é golpe.”
          </span>
        </p>
        <p className="mt-2 text-xs sm:text-sm text-purple-700 font-semibold">
          só se for pra golpear seu coração gatinha rsrs
        </p>
      </div>

      {/* Main Action Button */}
      <div className="flex flex-col items-center gap-2.5 w-full">
        <button
          onClick={handleStart}
          className="group relative inline-flex items-center justify-center gap-2.5 w-full max-w-[270px] px-6 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white font-bold text-sm sm:text-base shadow-lg shadow-purple-300/50 hover:shadow-pink-300/60 active:scale-[0.98] transition-all duration-300 border border-white/30 cursor-pointer"
        >
          <span>Tá, vou ver essa mizera</span>
          <ArrowDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
        </button>

        <span className="text-[11px] text-purple-600/70 font-mono">
          toque para descer e começar
        </span>
      </div>
    </section>
  );
};
