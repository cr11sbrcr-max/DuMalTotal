export interface PhotoSlotData {
  id: string;
  order: number;
  section: 'origem' | 'comeco' | 'gostos' | 'memorias' | 'amor';
  title: string;
  subtitle?: string;
  defaultImage: string;
  userImage?: string; // base64 or URL
  caption: string;
  date?: string;
  tag?: string;
  suggestedOriginal: string; // Tells Cauã which photo fits here
}

export interface FavoriteItem {
  id: string;
  title: string;
  category: string;
  image: string;
  photoSlotId: string;
  description: string;
  joke?: string;
  easterEggPrompt?: string;
  easterEggContent?: string;
  badge?: string;
  color: string;
}

export interface FlawItem {
  flaw: string;
  question: string;
  cauãAnswer: string;
  percentage: number;
  explanation: string;
  status: 'admitido' | 'em_tratamento' | 'curado' | 'permanente';
}

export interface LoveFeatureItem {
  title: string;
  subtitle: string;
  text: string;
  photoSlotId: string;
  quote: string;
}
